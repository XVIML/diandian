#==import related package====
import tkinter as tk
import numpy as np
from scipy import signal
from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt
import drvi.drviDSP as dsp
import drvi.drviControlls as dr

#=================================
def getWTFilter(v):
    h1=[-0.014,0.050,0.018,-0.097,-0.020,0.315,0.521,0.315,-0.020,-0.097,0.018,0.050,-0.014];
    g1=[-0.014,-0.050,0.018,0.097,-0.020,-0.315,0.521,-0.315,-0.020,0.097,0.018,-0.050,-0.014];
    N=len(h1)
    if v==0: return N,h1,g1        
    M=2**(v-1)
    N1=(M+1)*N
    h=np.zeros(N1-M)
    g=np.zeros(N1-M)
    for i in range(N):
        h[(M+1)*i]=h1[i]
        g[(M+1)*i]=g1[i]
    N1=len(h)    
    return N1,h,g

def working():
    fig1,ax1=plt.subplots(nrows=5,ncols=2)
    fig2,ax2=plt.subplots(nrows=5,ncols=2)
    fig3,ax3=plt.subplots()
    fig1.tight_layout()
    fig2.tight_layout()
    fig3.tight_layout()    
    for i in range(5):
        N,h1,g1=getWTFilter(i)
        w,h=signal.freqz(h1)
        Ah=np.abs(h)
        k=np.arange(N)-int(N/2)
        ax1[i][0].stem(k,h1)
        ax1[i][1].plot(w,Ah)
        ax1[i][0].set_xlim(-31,31)
        ax1[i][1].set_xlim(0,np.pi)
        #============
        w,h=signal.freqz(g1)
        Ag=np.abs(h)
        ax2[i][0].stem(k,g1)
        ax2[i][1].plot(w,Ag)
        ax2[i][0].set_xlim(-31,31)
        ax2[i][1].set_xlim(0,np.pi)
        #=============
        if i==0:
            ax3.plot(w,Ag)
            A=Ah
        else:
            Ak=A*Ag
            ax3.plot(w,Ak)
            A=A*Ah
        if i==4:
            ax3.plot(w,A)
        ax3.set_xlim(0,np.pi)
    mFig1.setValueFig(fig1)
    mFig2.setValueFig(fig2)
    mFig3.setValueFig(fig3)  

#==Widgets Resize================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
win.wm_title('DRVI-离散小波变换的数字滤波算法实验')
winWidthCur=1120
winHeightCur=680
win.geometry('1120x680')
win.config(bg="#ddeeee")
win.bind("<Configure>",winResize)
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
#==Layout of controls=================
mTab=dr.DRNoteBook(win,10,10,1100,660,'#dddddd','#888888','#000000','低通滤波器,高通滤波器,多尺度分解')
mFig1=dr.DRFigure(mTab.win[0],5,5,1090,650)
mFig2=dr.DRFigure(mTab.win[1],5,5,1090,650)
mFig3=dr.DRFigure(mTab.win[2],5,5,1090,650)
#====================
working()
#==Add sizeable widgets=======
mWidSize.addDRWidget(mTab)
mWidSize.addDRWidget(mFig1)
mWidSize.addDRWidget(mFig2)
mWidSize.addDRWidget(mFig3)
#==Main Loop=====================
win.mainloop()
#==End of APPp=================

