import control as ct
import numpy as np
import matplotlib.pyplot as plt

#定义系统
s = ct.tf('s')
sys = (s**2+s*2+1)/(s**3+s**2+5*s+4)

#仿真响应
t, y = ct.step_response(sys)
plt.plot(t, y)
plt.grid()
plt.show()

#PID控制器参数
Kp = 30
Ki = 10
Kd = 1
pid = ct.TransferFunction([Kd, Kp, Ki], [1, 0])

#闭环系统
closed_loop_sys = ct.feedback(pid*sys,1)

#仿真响应
t, y = ct.step_response(closed_loop_sys)
plt.plot(t, y)
plt.grid()
plt.show()
