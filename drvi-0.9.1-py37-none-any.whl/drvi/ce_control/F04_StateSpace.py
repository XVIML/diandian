# era_msd.py
# Johannes Kaisinger, 4 July 2024
# Demonstrate estimation of State Space model from impulse response.

import numpy as np
import matplotlib.pyplot as plt
import os
import control as ct

# set up a mass spring damper system (2dof, MIMO case)
# Mechanical Vibrations: Theory and Application, SI Edition, 1st ed.
# Figure 6.5 / Example 6.7
# m q_dd + c q_d + k q = f
m1, k1, c1 = 1., 4., 1.
m2, k2, c2 = 2., 2., 1.
k3, c3 = 6., 2.

A = np.array([
    [0., 0., 1., 0.],
    [0., 0., 0., 1.],
    [-(k1+k2)/m1, (k2)/m1, -(c1+c2)/m1, c2/m1],
    [(k2)/m2, -(k2+k3)/m2, c2/m2, -(c2+c3)/m2]
])
B = np.array([[0.,0.],[0.,0.],[1/m1,0.],[0.,1/m2]])
C = np.array([[1.0, 0.0, 0.0, 0.0],[0.0, 1.0, 0.0, 0.0]])
D = np.zeros((2,2))

sys = ct.StateSpace(A, B[:,0], C[0,:], D[0,0])


#特性图
ct.bode_plot(sys)
plt.show()
ct.nyquist_plot(sys)
plt.show()
ct.root_locus(sys)
plt.show()

#响应
t, y = ct.step_response(sys)
plt.plot(t, y)
plt.grid()
plt.show()

