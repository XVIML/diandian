import control as ct
import numpy as np
import matplotlib.pyplot as plt

#定义系统
s = ct.tf('s')
sys = (s**2+s*2+1)/(s**3+s**2+5*s+4)


#响应
t, y = ct.impulse_response(sys) 
plt.plot(t, y)
plt.ylim(-1,1)
plt.show()
t, y = ct.step_response(sys)
plt.plot(t, y)
plt.ylim(-1,1)
plt.show()

