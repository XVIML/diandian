import control as ct
import numpy as np
import matplotlib.pyplot as plt

#定义系统
s = ct.tf('s')
sys = (s**2+s*2+1)/(s**3+s**2+5*s+4)

#特性图
ct.bode_plot(sys)
plt.show()
ct.nyquist_plot(sys)
plt.show()
ct.nichols_plot(sys)
plt.show()
ct.pzmap(sys, plot=True)
plt.show()
ct.root_locus(sys)
plt.show()


poles = ct.pole(sys)
if all(poles.real < 0):
    print("系统稳定")
else:
    print("系统不稳定")


