import control as ct
import numpy as np
import matplotlib.pyplot as plt


# parameters
m=10
ks=100
kd=5

# system matrices
A=np.array([[0, 1],[-ks/m, -kd/m]])
B=np.array([[0],[1/m]])
C=np.array([[1,0]])
D=np.array([[0]])

#define sys
sysStateSpace=ct.ss(A,B,C,D)
print(sysStateSpace)

#define the initial condition
x0=np.array([[0],[0]])


# define the time vector for simulation
startTime=0
endTime=20
numberSamples=500
timeVector=np.linspace(startTime,endTime,numberSamples)

# define the control input vector for simulation
controlInputVector=np.ones(numberSamples)


# simulate the system 
# 1 input argument - state-space model 
# 2 input argument - time vector 
# 3 input argument - defined control input
# 4 input argument - initial state for simulation
returnSimulation = ct.forced_response(sysStateSpace,
                                      timeVector,
                                      controlInputVector,
                                      x0)

# outputs of the forced_response is 
# the TimeResponseData object consisting of 
# time values of returned objects     
returnSimulation.time
# computed outputs of the system 
returnSimulation.outputs
# state sequence of the system
returnSimulation.states 
# inputs used for simulation
returnSimulation.inputs


plt.plot(returnSimulation.time,returnSimulation.outputs)
plt.show()


##############################################################
# design the LRQ controller
##############################################################

# state weighting matrix
Q=100*np.array([[10,0],[0,10]])
 
# input weighting matrix
R=1*np.array([[1]])
 
# K - gain matrix 
# S - solution of the Riccati equation 
# E - closed-loop eigenvalues 
 
K, S, E = ct.lqr(sysStateSpace, Q, R)

Acl=A-np.matmul(B,K)
Bcl=-Acl
Dcl=np.array([[0,0]])
 
# define the state-space model
sysStateSpaceCl=ct.ss(Acl,Bcl,C,Dcl)

# define the time vector for simulation
timeVector=np.linspace(startTime,endTime,numberSamples)

# define the desired state 
xd=np.array([[2],[0]])
 
# define the input for closed-loop simulation
inputCL=np.zeros(shape=(2,numberSamples))
inputCL[0,:]=xd[0,0]*np.ones(numberSamples)
inputCL[1,:]=xd[1,0]*np.ones(numberSamples)
 
 
returnSimulationCL = ct.forced_response(sysStateSpaceCl,
                                      timeVector,
                                      inputCL,
                                      x0)


plt.plot(returnSimulationCL.time,returnSimulationCL.states[0,:])
plt.show()







