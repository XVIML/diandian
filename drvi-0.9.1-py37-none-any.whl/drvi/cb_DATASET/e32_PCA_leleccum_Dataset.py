import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat
import drvi.drviAppendPath as mPath

mFile=mPath.getDRVIPath()+'\\dataset\\leleccum.mat'
mat = loadmat(mFile)
x = mat['leleccum'][0]

# plot signal
plt.plot(x)
plt.show()
