import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

data = sm.datasets.co2.load_pandas().data
dta = pd.Series(data['co2'].values.squeeze())
 
plt.plot(dta)
plt.show()

