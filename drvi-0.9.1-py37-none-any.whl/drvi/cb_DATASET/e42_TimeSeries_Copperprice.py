import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

data = sm.datasets.copper.load_pandas().data
dta = pd.Series(data['COPPERPRICE'].values.squeeze())

plt.plot(dta)
plt.show()
