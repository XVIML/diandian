import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

data = sm.datasets.sunspots.load_pandas().data
dta = pd.Series(data['SUNACTIVITY'].values.squeeze())
 
plt.plot(dta)
plt.show()

