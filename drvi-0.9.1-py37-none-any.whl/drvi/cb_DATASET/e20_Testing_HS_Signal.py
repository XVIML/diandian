import matplotlib.pyplot as plt
import numpy as np
import drvi.drviDSP as dsp

mSys=dsp.DRTester()
mSys.setHS(txt='1/(s**2+10*s+10000)')
fMax=mSys.getMaxF()

N=1024
Fs=5*fMax
t=np.arange(N)*(1.0/Fs)
xIn=0.333333*np.random.randn(N)

mSys.setValue2D(t,xIn)
t,yOut=mSys.getValue2DR()

fig,ax=plt.subplots(2,1)
ax[0].plot(t,xIn)
ax[1].plot(t,yOut)
plt.show()

