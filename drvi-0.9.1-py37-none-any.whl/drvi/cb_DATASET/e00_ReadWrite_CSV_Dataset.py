import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

Fs=1000
N=512
t=np.arange(N)/Fs
y=np.sin(2*np.pi*50*t)

dataframe=pd.DataFrame({'Time':t,'Value':y})
dataframe.to_csv("test.csv",index=True,sep=',')

data=pd.read_csv('test.csv')
t1 = pd.Series(data['Time'].values.squeeze())
y1 = pd.Series(data['Value'].values.squeeze())

# plot signal
fig, axs = plt.subplots(2, 1)
axs[0].plot(t,y)
axs[1].plot(t1,y1)
plt.show()
