import matplotlib.pyplot as plt
import numpy as np
#from scipy.misc import electrocardiogram
from drvi.misc import electrocardiogram


ecg=electrocardiogram()
Fs=360
N=ecg.size
dt=1/Fs
t=np.arange(3600)*dt
for i in range(10):
    plt.plot(t,ecg[i*3600:i*3600+3600]-i*3)
plt.show()

