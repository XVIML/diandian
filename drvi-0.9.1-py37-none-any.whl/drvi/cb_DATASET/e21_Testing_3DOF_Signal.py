import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import drvi.drviDSP as dsp

#==主程序===========
abc=dsp.DRTester()
m0=10
m1=50
m2=100
c0=c1=c2=15
k0=k1=k2=1500
M=np.array([[m0,0,0],[0,m1,0],[0,0,m2]])
K=np.array([[k0+k1,-k1,0],[-k1,k1+k2,-k2],[0,-k2,k2]])
C=np.array([[c0+c1,-c1,0],[-c1,c1+c2,-c2],[0,-c2,c2]])
abc.setMCK(3,M,C,K)

maxF=abc.getMaxF()
minF=abc.getMinF()

Fs=4*maxF
N=2048
dt=1.0/Fs;
TT=N*dt
t=np.arange(N)*dt
inF=signal.chirp(t,0.1*minF,TT,1.5*maxF)

abc.setValue2D(t,inF,0)
t,yOut1=abc.getValue2DR(1)
t,yOut2=abc.getValue2DR(2)
t,yOut3=abc.getValue2DR(3)

fig,ax=plt.subplots(4,1)
ax[0].plot(t,inF)
ax[1].plot(t,yOut1)
ax[2].plot(t,yOut2)
ax[3].plot(t,yOut3)
plt.show()

