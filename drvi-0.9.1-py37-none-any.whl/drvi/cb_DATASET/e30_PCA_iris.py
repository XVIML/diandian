import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
# 加载鸢尾花数据集
iris = load_iris()
X = iris.data
y = iris.target
fig,ax=plt.subplots(nrows=4,ncols=1)
ax[0].plot(X[:,0])
ax[1].plot(X[:,1])
ax[2].plot(X[:,2])
ax[3].plot(X[:,3])
plt.show()
