import numpy as np
from scipy import signal
import matplotlib.pyplot as plt    

#==产生数据====
ch=4
Fs=500;
N=500
dt=1.0/Fs;
t=np.arange(N)*dt
x1=0.8*np.sin(2*np.pi*10*t)
x2=0.8*signal.square(2*np.pi*10*t)
x3=0.8*signal.sawtooth(2*np.pi*10*t)
x4=0.3333*np.random.randn(N)

#==保存为npz数据文件===
mfile='test.npz'
txt='数据文件内容摘要:\n'
txt=txt+'Fs:浮点，采样频率\n'
txt=txt+'N:整型，采样长度\n'
txt=txt+'CH:整型，信号通道数\n'
txt=txt+'CH1:浮点数组，通道1数据\n'
txt=txt+'CH2:浮点数组，通道21数据\n'
txt=txt+'CH3:浮点数组，通道3数据\n'
txt=txt+'CH4:浮点数组，通道4数据\n'
np.savez(mfile,about=txt,Fs=Fs,N=N,CH=ch,CH1=x1,CH2=x2,CH3=x3,CH4=x4)

#==加载npz数据文件===
mfile='test.npz'
allData=np.load(mfile)
txt=allData['about']
print(txt)
Fs=allData['Fs']
N=allData['N']    
x1=allData['CH1']
x3=allData['CH3']
t=np.arange(N)*(1/Fs)

# plot signal===
fig,ax=plt.subplots(2,1)
ax[0].plot(t,x1)
ax[1].plot(t,x3)
plt.show()

