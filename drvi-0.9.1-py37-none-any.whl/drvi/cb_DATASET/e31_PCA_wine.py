import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
from sklearn.decomposition import PCA
# 加载葡萄酒数据集
iris = load_wine()
X = iris.data
y = iris.target
fig,ax=plt.subplots(nrows=13,ncols=1)
for i in range(13):
    ax[i].plot(X[:,i])
plt.show()
