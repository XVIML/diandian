
#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import sys
import numpy as np
import drvi.drviDSP as dsp
import drvi.drviQTControlls as drqt


#===Start of MainClass=================================================================
class drviMain(QMainWindow):
    def __init__(self):
        super(drviMain,self).__init__()
        self.initGUI()
    
    #===菜单响应函数================================ 
    def myFile(self, q):
        if q.text() == "Close":
            sys.exit(app.exec_())
        if q.text() == "About":
            QMessageBox.information(QWidget(),'About', 'This is a APP frame by DRPython', QMessageBox.Yes)

    def resizeEvent(self, event):
        w=event.size().width()
        h=event.size().height()
        if (w<100) or (h<100): return
        if hasattr(self,"mWidSize"):
            self.mWidSize.resize(w,h)
        else:
            self.mWidSize=drqt.DRResize(w,h)
            self.addSizeWidget()
            
    #===GUI初始化==================================
    def initGUI(self):
        self.setWindowTitle("DRVI-MIC声音信号波形和频谱 -- By DRPython")
        self.resize(1040,650)
        self.win=QWidget()
        self.win.setStyleSheet('background-color : #ddeeee; ')
        self.setCentralWidget(self.win)   

        #=添加状态条================================
        self.statusBar=QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.setStyleSheet('background-color : #eeeeee; ')
        self.statusBar.showMessage('Ready',0)

        #=添加菜单================================
        self.menuBar=self.menuBar()
        self.menuBar.setStyleSheet('background-color : #eeeeee; ')
        self.fileItem=self.menuBar.addMenu("File")
        self.fileItem.addAction("About")
        self.fileItem.addAction("Close")
        self.fileItem.triggered.connect(self.myFile)

        #=添加控件================================
        self.mLab2=drqt.DRLabel(self.win,20,10,400,36,'#005588','#ffffff','MIC声音信号波形和频谱',20)        
        self.mHBut=drqt.DRHButtonGroup(self.win,750,10,160,36,'#005588','#ffffff','运行,停止',12)
        self.mPlotWave=drqt.DRPlotFast(self.win,20,50, 1000,280,0,0,0.085,-1,1,0,0)
        self.mPlotAmp  =drqt.DRPlotFast(self.win,20,320,1000,280,0,0,6000,0,0.25,0,0)
        self.myMIC=drqt.DRRecorder(self.win,920,10,100,36,'#000000','#eeee00',Fs=44100,nChunk=4)                
        #==事件流、数据流绑定===========================
        self.myMIC.addCallBack2DX(self.setValue2DX)
        self.mHBut.addCallBackSingle(self.myMIC.setVSOnOff)  

    def addSizeWidget(self):
        #==Add sizeable widgets=======
        self.mWidSize.addDRWidget(self.mLab2)
        self.mWidSize.addDRWidget(self.mHBut)
        self.mWidSize.addDRWidget(self.myMIC)
        self.mWidSize.addDRWidget(self.mPlotWave)
        self.mWidSize.addDRWidget(self.mPlotAmp)        

    #==事件流、数据流响应函数=======================
    def setValue2DX(self,dx,xArray):
        Fs=1/dx
        N=len(xArray)
        mFre,mAmp=dsp.AmpSpetrum(N,Fs,xArray)
        self.mPlotWave.setValue2DX(dx,xArray)
        self.mPlotAmp.setValue2D(mFre,mAmp)    
            
#===End of MainClass========================================= 
            

#===========================================================
app=QApplication(sys.argv)
win=drviMain()
win.show()
sys.exit(app.exec_())
#============================================================
