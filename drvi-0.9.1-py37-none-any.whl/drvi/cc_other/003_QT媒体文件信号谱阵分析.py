#pyqt采用系统注册的视频播放器进行视频文件的解压，如果视频模块不能工作，
#请装安装一个较全的视频解码器软件，如：K-Lite


#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import sys
import numpy as np
import drvi.drviDSP as dsp
import drvi.drviQTControlls as drqt

#===Start of MainClass=================================================================
class drviMain(QMainWindow):
    def __init__(self):
        super(drviMain,self).__init__()
        self.initGUI()
    
    #===菜单响应函数================================ 
    def myFile(self, q):
        if q.text() == "Close":
            sys.exit(app.exec_())
        if q.text() == "About":
            QMessageBox.information(QWidget(),'About', 'This is a APP frame by DRPython', QMessageBox.Yes)
            
    #===GUI初始化==================================
    def initGUI(self):
        self.setWindowTitle("DRVI-MP4文件波形和频谱 -- By DRPython")
        self.resize(1040,650)
        self.win=QWidget()
        self.win.setStyleSheet('background-color : #ddeeee; ')
        self.setCentralWidget(self.win)   

        #=添加状态条================================
        self.statusBar=QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.setStyleSheet('background-color : #eeeeee; ')
        self.statusBar.showMessage('Ready',0)

        #=添加菜单================================
        self.menuBar=self.menuBar()
        self.menuBar.setStyleSheet('background-color : #eeeeee; ')
        self.fileItem=self.menuBar.addMenu("File")
        self.fileItem.addAction("About")
        self.fileItem.addAction("Close")
        self.fileItem.triggered.connect(self.myFile)

        #=添加控件================================
        self.mLab2=drqt.DRLabel(self.win,20,10,300,36,'#005588','#ffffff','MP4文件实时谱阵分析',20)
        self.mFile=drqt.DREntry(self.win,600,10,310,36,'#000000','#ffff00','',12)
        self.mPlayer=drqt.DRPlay(self.win,920,10,80,36,'#000000','#ffff00',11,'')                
        self.mBut=drqt.DRHButtonGroup(self.win,400,10,190,36,'#006655','#ffff00','运行,停止,文件',12)
        self.mPlot3=drqt.DRArrayX(self.win,20,60,980,530,cb='#003355',cf='#ffffff',dx=1,dy=2,xlow=0,xhigh=6000,ylow=-0,yhigh=0.25)
                
        #==事件流、数据流绑定===========================
        self.mBut.addCallBackSingle(self.mPlayer.setValueSingle)        
        self.mPlayer.addCallBack2DX(self.setValue2DX)
        self.mPlayer.addCallBackStrFile(self.mFile.setValueString)
        
        #==初始运行状态=================================
        self.TT=0
        self.initFile=mPath.getDRVIPath()+'\\dataset\\video_dream.mp4'
        self.mFile.setValueString(self.initFile)
        self.mPlayer.setValueString(self.initFile)
        
    #==============================================
    def resizeEvent(self, event):
        w=event.size().width()
        h=event.size().height()
        if (w<100) or (h<100): return
        if hasattr(self,"mWidSize"):
            self.mWidSize.resize(w,h)
        else:
            self.mWidSize=drqt.DRResize(w,h)
            self.addSizeWidget()

    def addSizeWidget(self):
        self.mWidSize.addDRWidget(self.mLab2)
        self.mWidSize.addDRWidget(self.mFile)
        self.mWidSize.addDRWidget(self.mPlayer)
        self.mWidSize.addDRWidget(self.mBut)
        self.mWidSize.addDRWidget(self.mPlot3)   

    #==事件流、数据流响应函数=======================
    def setFile(self,v):
        self.mPlayer.setValueSingle(2)

    def setValue2DX(self,dx,xArray):
        Fs=1/dx; N=len(xArray)
        CH=xArray.ndim
        if CH==2:
            xArray=xArray[:,0] #立体声，取一通道数据        
        mFre,mAmp=dsp.AmpSpetrum(N,Fs,xArray)
        self.mPlot3.setValue2D(mFre,mAmp)  
            
#===End of MainClass========================================= 
            

#===========================================================
app=QApplication(sys.argv)
win=drviMain()
win.show()
sys.exit(app.exec_())
#============================================================
