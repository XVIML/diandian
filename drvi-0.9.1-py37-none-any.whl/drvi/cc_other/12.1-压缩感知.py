import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from scipy.fftpack import dct, idct

#时间轴上的观测对象
def getSignal(t):
    y=np.sin(2*np.pi*20*t)+0.3*np.sin(2*np.pi*140*t)
    return y

#采样频率和采样间隔
Fs=2048
dt=1/Fs

#按采样定理的等间隔采样信号，即作为对比的原信号
n = 2048
t=np.arange(n)*dt
y=getSignal(t)

#时间轴上的非等间隔采样，即稀疏采样(压缩采样)，此处8倍压缩
m = 256  
ti=np.random.choice(n,m,replace=False) #重点，生成随机采样点
ti.sort()
tcs = t[ti]
ycs=getSignal(tcs)  #只在少量时刻采样，即压缩采样

#重点，将压缩采样信号重构为等间隔采样的信号
D = dct(np.eye(n)) # Here, we model using the DCT
A = D[ti, :]
lasso = linear_model.Lasso(alpha=0.001)# here, we use lasso to minimize the L1 norm
lasso.fit(A, ycs.reshape((m,)))
# Creates the fourier transform that will most minimize l1 norm 
yrec = idct(lasso.coef_.reshape((n, 1)), axis=0) # inverse fourier transfomr 


#显示原信号和重构信号，做对比
fig,ax=plt.subplots(nrows=3,ncols=1)
ax[0].stem(tcs,ycs,'#ddaa00',markerfmt=' ',basefmt=None)
ax[0].plot(t,y,c='#0077aa')
ax[0].grid()
ax[1].plot(tcs,ycs)
ax[1].grid()
ax[2].plot(t,yrec)
ax[2].grid()
plt.show()








