#pyqt采用系统注册的视频播放器进行视频文件的解压，如果视频模块不能工作，
#请装安装一个较全的视频解码器软件，如：K-Lite

import tkinter as tk
import numpy as np
import cv2
import drvi.drviControlls as dr
import drvi.drOpenCV as drcv
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

 
#==CallBack Function==============
def setType(v):
    global st,initVideo,initImage
    st=v
    if v==0:
        mEntry.setValueString('')
    if v==1:
        mEntry.setValueString(initVideo)
        mFileBut.ext='mp4'        
    if v==2:
        mEntry.setValueString(initImage)
        mFileBut.ext='jpg'
    
def setFile(v):
    global st,initVideo,initImage
    if st==0: return
    if st==1:
        initVideo=v
        mEntry.setValueString(initVideo)
        mp4Video.setValueString(initVideo)
    if st==2:
        initImage=v
        mEntry.setValueString(initImage)

def setRun(v):
    global st,initVideo,initImage
    if st==0:
        mCamera.setValueSingle(v)
    if st==1:
        mp4Video.setValueSingle(v)
    if st==2:
        mData=cv2.imread(initImage)
        mData = cv2.cvtColor(mData, cv2.COLOR_BGR2RGBA)
        myWorking(mData)
    
#==========================================================
def myWorking(v):
    global face_cascade
    img0=v
    gray=cv2.cvtColor(img0, cv2.COLOR_RGB2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    for (x, y, w, h) in faces:
        cv2.rectangle(gray, (x, y), (x+w, y+h), (255, 0, 0), 8)            
    mSubImg.setValueImage(img0) 
    mSubImg.setValueImage1(gray)

#====================================    
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)
    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1000
winHeightCur=500
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-图形的人脸检测')

st=2
initVideo=mPath.getDRVIPath()+'\\dataset\\face.mp4'
initImage=mPath.getDRVIPath()+'\\dataset\\face.jpg'
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

#==Layout of controls=====================
mL1=dr.DRLabel(win,20,25,250,40,'#440000','#ffffff','图象的人脸检测',20)
mFileBut=dr.DRFileBut(win,300,30,60,30,'#003355','#eeee00','文件','mp4',12)
mEntry=dr.DREntry(win,370,30,390,30,'#ffffff','#000000',initImage,12)
mOMenu=dr.DROptionMenu(win,775,30,100,30,'#003355','#eeee00','摄像头,视频文件,图片文件',12,2)
mButton=dr.DRButton(win,880,30,100,30,'#003355','#eeee00','运行/停止',12,101)
mSubImg=dr.DRSubImages(win,20,80,960,400,'#003355',1,2)
mp4Video=drcv.DRVideoCV(mfile=initVideo,mid=700,imgType=0,rate=10)
mCamera=drcv.DRCameraCV(win,600,20,80,40,mid=700,imgType=0,sleep=100)

#=User defined data probe============
mOMenu.addCallBackSingle(setType)
mFileBut.addCallBackString(setFile)
mButton.addCallBackSingle(setRun)
mCamera.addCallBackImage(myWorking)
mp4Video.addCallBackImage(myWorking)

#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mFileBut)
mWidSize.addDRWidget(mEntry)
mWidSize.addDRWidget(mOMenu)
mWidSize.addDRWidget(mButton)
mWidSize.addDRWidget(mSubImg)

#==Main Loop=====================
win.mainloop()
