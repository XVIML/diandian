#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#========================

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import sys
import cv2
import math
import numpy as np
import drvi.drviDSP as dsp
import drvi.drviQTControlls as drqt
      

#===Start of MainClass=================================================================
class drviMain(QMainWindow):
    def __init__(self):
        super(drviMain,self).__init__()
        self.initGUI()

    def resizeEvent(self, event):
        w=event.size().width()
        h=event.size().height()
        if (w<100) or (h<100): return
        if hasattr(self,"mWidSize"):
            self.mWidSize.resize(w,h)
        else:
            self.mWidSize=drqt.DRResize(w,h)
            self.addSizeWidget()
            
    #===GUI初始化==================================
    def initGUI(self):
        self.setWindowTitle("摄像头音频视频信号采集")
        self.resize(1040,450)
        self.win=QWidget()
        self.win.setStyleSheet('background-color : #ddeeee; ')
        self.setCentralWidget(self.win)   

        #=添加控件================================
        self.mLab2=drqt.DRLabel(self.win,20,10,400,36,'#005588','#ffffff','摄像头音频视频信号采集',20)        
        self.mHBut=drqt.DRHButtonGroup(self.win,750,10,160,36,'#005588','#ffffff','运行,停止',12)
        self.mImg=drqt.DRImage(self.win,20,60,400,380,'#003355')
        self.mPlotWave=drqt.DRPlotFast(self.win,430,60,600,190,0,0,0.085,-1,1,0,0)
        self.mPlotAmp  =drqt.DRPlotFast(self.win,430,250,600,190,0,0,6000,0,0.25,0,0)        
        self.rec=drqt.DRRecorder(self.win,920,10,100,36,'#000000','#eeee00',Fs=44100,nChunk=4,sVideo=1)                
        #==事件流、数据流绑定===========================
        self.rec.addCallBack2DX(self.setValue2DX)
        self.rec.addCallBackImage(self.processVideo)
        self.mHBut.addCallBackSingle(self.rec.setVSOnOff)  

    def addSizeWidget(self):
        #==Add sizeable widgets=======
        self.mWidSize.addDRWidget(self.mLab2)
        self.mWidSize.addDRWidget(self.mHBut)
        self.mWidSize.addDRWidget(self.mPlotWave)
        self.mWidSize.addDRWidget(self.mPlotAmp)
        self.mWidSize.addDRWidget(self.mImg)  
    #==事件流、数据流响应函数=======================
    def setValue2DX(self,dx,xArray):
        Fs=1/dx
        N=len(xArray)
        mFre,mAmp=dsp.AmpSpetrum(N,Fs,xArray)
        self.mPlotWave.setValue2DX(dx,xArray)
        self.mPlotAmp.setValue2D(mFre,mAmp)    

    def processVideo(self,v):
        self.mImg.setValueImage(v)              

#=============================== 
app=QApplication(sys.argv)
win=drviMain()
win.show()
sys.exit(app.exec_()) 
