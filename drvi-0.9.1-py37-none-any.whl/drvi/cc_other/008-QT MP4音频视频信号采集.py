
#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtMultimediaWidgets import *
from PyQt5.QtMultimedia import *
import sys
import cv2
import numpy as np
import drvi.drviDSP as dsp
import drvi.drviQTControlls as drqt


#===Start of MainClass=================================================================
class drviMain(QMainWindow):
    def __init__(self):
        super(drviMain,self).__init__()
        self.initGUI()
                
    #===GUI初始化==================================
    def initGUI(self):
        self.setWindowTitle("MP4音频视频信号采集")
        self.resize(1060,460)
        self.win=QWidget()
        self.win.setStyleSheet('background-color : #ddeeee; ')
        self.setCentralWidget(self.win)

        #=添加控件================================
        self.mLab2=drqt.DRLabel(self.win,20,10,320,36,'#005588','#ffffff','MP4音频视频信号采集',20)
        self.mFile=drqt.DREntry(self.win,570,10,380,36,'#000000','#ffff00','',11)
        self.mImg1=drqt.DRImage(self.win,20,60,400,380,'#003355')
        self.mPlotWave=drqt.DRPlotFast(self.win,430,60,620,190,0,0,0.085,-1,1,0,0)
        self.mPlotAmp  =drqt.DRPlotFast(self.win,430,250,620,190,0,0,6000,0,0.25,0,0)        
        self.mPlayer=drqt.DRPlay(self.win,960,10,80,36,'#000000','#ffff00',mShow=1,sVideo=1)
        self.mBut=drqt.DRHButtonGroup(self.win,370,10,190,36,'#006655','#ffff00','运行,停止,文件',12)
                
        #==事件流、数据流绑定===========================
        self.mBut.addCallBackSingle(self.mPlayer.setValueSingle)
        self.mPlayer.addCallBack2DX(self.setValue2DX)
        self.mPlayer.addCallBackStrFile(self.mFile.setValueString)
        self.mPlayer.addCallBackImage(self.myImage)
        
        #==初始运行状态=================================
        self.TT=0
        self.initFile=mPath.getDRVIPath()+'\\dataset\\video_dream.mp4'
        self.mFile.setValueString(self.initFile)
        self.mPlayer.setValueString(self.initFile)
        
    #==============================================
    def resizeEvent(self, event):
        w=event.size().width()
        h=event.size().height()
        if (w<100) or (h<100): return
        if hasattr(self,"mWidSize"):
            self.mWidSize.resize(w,h)
        else:
            self.mWidSize=drqt.DRResize(w,h)
            self.addSizeWidget()

    def addSizeWidget(self):
        self.mWidSize.addDRWidget(self.mLab2)
        self.mWidSize.addDRWidget(self.mFile)
        self.mWidSize.addDRWidget(self.mPlayer)
        self.mWidSize.addDRWidget(self.mPlotWave)
        self.mWidSize.addDRWidget(self.mPlotAmp)
        self.mWidSize.addDRWidget(self.mBut)
        self.mWidSize.addDRWidget(self.mImg1)
        

    #==事件流、数据流响应函数=======================
    def setFile(self,v):
        self.mPlayer.setValueSingle(2)

    def setValue2DX(self,dx,xArray):
        Fs=1/dx; N=len(xArray)
        CH=xArray.ndim
        if CH==2:
            xArray=xArray[:,0] #立体声，取一通道数据        
        mFre,mAmp=dsp.AmpSpetrum(N,Fs,xArray)
        self.mPlotWave.setValue2DX(dx,xArray)
        self.mPlotAmp.setValue2D(mFre,mAmp)          

    def myImage(self,v):
        self.mImg1.setValueImage(v)
           

#===========================================================
app=QApplication(sys.argv)
win=drviMain()
win.show()
sys.exit(app.exec_())
#============================================================
