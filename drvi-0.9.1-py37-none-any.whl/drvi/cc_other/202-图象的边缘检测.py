#pyqt采用系统注册的视频播放器进行视频文件的解压，如果视频模块不能工作，
#请装安装一个较全的视频解码器软件，如：K-Lite


import tkinter as tk
import numpy as np
import cv2
import drvi.drviControlls as dr
import drvi.drOpenCV as drcv
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

 
#==CallBack Function==============
def setType(v):
    global st,initVideo,initImage
    st=v
    if v==0:
        mEntry.setValueString('')
    if v==1:
        mEntry.setValueString(initVideo)
        mFileBut.ext='mp4'        
    if v==2:
        mEntry.setValueString(initImage)
        mFileBut.ext='jpg'
    
def setFile(v):
    global st,initVideo,initImage
    if st==0: return
    if st==1:
        initVideo=v
        mEntry.setValueString(initVideo)
        mp4Video.setValueString(initVideo)
    if st==2:
        initImage=v
        mEntry.setValueString(initImage)

def setRun(v):
    global st,initVideo,initImage
    if st==0:
        mCamera.setValueSingle(v)
    if st==1:
        mp4Video.setValueSingle(v)
    if st==2:
        mData=cv2.imread(initImage)
        mData = cv2.cvtColor(mData, cv2.COLOR_BGR2RGBA)
        myWorking(mData)
    
#==========================================================
def myWorking(v):
    img0=v
    gray_img=cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)  
    eq_img = cv2.equalizeHist(gray_img)
    edges_img = cv2.Canny(eq_img, 128, 256)

    mSubImg.setValueImage(img0) 
    mSubImg.setValueImage1(gray_img)                    
    mSubImg.setValueImage2(eq_img)
    mSubImg.setValueImage3(edges_img)

#====================================    
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)
    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1000
winHeightCur=670
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-图形的RGB分解')

st=0
initVideo=mPath.getDRVIPath()+'\\dataset\\video_dream.mp4'
initImage=mPath.getDRVIPath()+'\\dataset\\PhotoColor.jpg'

#==Layout of controls=====================
mL1=dr.DRLabel(win,20,25,250,40,'#440000','#ffffff','图象的RGB分解',20)
mFileBut=dr.DRFileBut(win,300,30,60,30,'#003355','#eeee00','文件','mp4',12)
mEntry=dr.DREntry(win,370,30,390,30,'#ffffff','#000000','',12)
mOMenu=dr.DROptionMenu(win,775,30,100,30,'#003355','#eeee00','摄像头,视频文件,图片文件',12,0)
mButton=dr.DRButton(win,880,30,100,30,'#003355','#eeee00','运行/停止',12,101)
mSubImg=dr.DRSubImages(win,20,80,960,580,'#003355',2,2)
mp4Video=drcv.DRVideoCV(mfile=initVideo,mid=700,imgType=0,rate=10)
mCamera=drcv.DRCameraCV(win,600,20,80,40,mid=700,imgType=0,sleep=100)

#=User defined data probe============
mOMenu.addCallBackSingle(setType)
mFileBut.addCallBackString(setFile)
mButton.addCallBackSingle(setRun)
mCamera.addCallBackImage(myWorking)
mp4Video.addCallBackImage(myWorking)

#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mFileBut)
mWidSize.addDRWidget(mEntry)
mWidSize.addDRWidget(mOMenu)
mWidSize.addDRWidget(mButton)
mWidSize.addDRWidget(mSubImg)

#==Main Loop=====================
win.mainloop()
