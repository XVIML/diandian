import tkinter as tk
import numpy as np
import cv2
import drvi.drviControlls as dr
import drvi.drOpenCV as drcv
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
 
#==CallBack Function==============
def setRun(v):
    myWorking(0)
 
def setScript(v):
    S="#Drscript控件：输入in1,...in8；输出out1,...,out8\n"    
    S=S+"#本例：in5=Subplot1,in6=Subplot2,in7=Subplot4,in8=DRTab\n"    
    S=S+"#=======================================================\n"
    S=S+"import numpy as np\n"
    S=S+"from scipy import signal\n"
    S=S+"from scipy.fftpack import fft,ifft\n\n"

    S=S+"Fs=44100;\n"
    S=S+"N=2000;\n"
    S=S+"t=np.arange(N)*(1/Fs)\n"
    S=S+"x1=np.sin(2*np.pi*200*t)\n"
    S=S+"x2=np.sin(2*np.pi*800*t)\n"
    S=S+"x3=np.sin(2*np.pi*1600*t)\n"
    S=S+"x=x1+x2+x3\n"
    S=S+"y=np.abs(fft(x))\n"
    S=S+"f=np.arange(int(N/2))*(Fs/N);\n"
    S=S+"A=y[:int(N/2)]/(N/2);\n\n"

    S=S+"in6.setValue2D1(t,x)\n"
    S=S+"in6.setValue2D2(f,A)\n"
    S=S+"in8.setPage(2)\n"   

    mScript.setValueString(S)
    mTab.setPage(0)
    
    
#==========================================================
def myWorking(v):
    out=mScript.doScript(in5=mPlot1,in6=mPlot2,in7=mPlot4,in8=mTab)     
    
#====================================    
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1100
winHeightCur=670
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-Python信号分析脚本程序框架')
#==Layout of controls=====================
mTab=dr.DRNoteBook(win,5,5,1090,660,'#dddddd','#888888','#000000','Python脚本,一图,二图,四图')
mScript=dr.DRScript(mTab.win[0],5,5,1075,640,'#ffffff','#000000','',20)
mButton=dr.DRButton(win,990,50,80,40,'#005533','#ffffff','运行',12,101)
mPlot1=dr.DRPlot(mTab.win[1],5,5,1075,620)
mPlot2=dr.DRSubPlot(mTab.win[2],5,5,1075,620,'#003355','#000000','#ffffff','#00eeff','#ffff00',2,1,[0,0])
mPlot4=dr.DRSubPlot(mTab.win[3],5,5,1075,620,'#003355','#000000','#ffffff','#00eeff','#ffff00',2,21,[0,0,0,0])
#=User defined data probe============
mButton.addCallBackSingle(setRun)
#===============================
setScript(0) 
#=============================== 
mWidSize.addDRWidget(mButton)
mWidSize.addDRWidget(mScript)
mWidSize.addDRWidget(mTab)
#==Main Loop=====================
win.mainloop()
