import os
from shutil import copyfile
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()

#=当前路径和DRVI路径==
rootPath=os.getcwd();
drivPath=mPath.getDRVIPath()

#拷贝 DRVI主文件和样例文件到当前路径==
sFile=drivPath+'\\main\\DRPythonIDEX.py'
tFile=rootPath+'\\DRPython.py'
copyfile(sFile,tFile)
sFile=drivPath+'\\main\\DRCodeSet.py'
tFile=rootPath+'\\DRVI_Examples.py'
copyfile(sFile,tFile)
sFile=drivPath+'\\main\\ffmpeg.txt'
tFile=rootPath+'\\ffmpeg.txt'
copyfile(sFile,tFile)
sFile=drivPath+'\\main\\DRVIExample_Piano.py'
tFile=rootPath+'\\Example_Piano.py'
copyfile(sFile,tFile)
sFile=drivPath+'\\main\\DRVIExample_Spectrum.py'
tFile=rootPath+'\\Example_Spectrum.py'
copyfile(sFile,tFile)
sFile=drivPath+'\\main\\DRVIExample_Play.py'
tFile=rootPath+'\\Example_Play.py'
copyfile(sFile,tFile)

#==结束=====
print('建立DRVI初始工作环境：')
print('DRPython.py：        DRVI图形化编程环境')
print('DRVI_Examples.py：   DRVI编程案例集')
print('Example_Piano.py：   DRVI控件实现的小电子琴样例')
print('Example_Spectrum.py：DRVI控件实现的典型信号频谱分析样例')
print('Example_Play.py：    DRVI控件实现的WAV音频文件分析样例')
print('完成')
