#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
import tkinter as tk
from PyEMD import EMD
import drvi.drviDSP as dsp
import drvi.drviControlls as dr
#from scipy.misc import electrocardiogram
from drvi.misc import electrocardiogram
        
#==Event response function of controls====
def setSignal(v):   
    global N,Fs,t,x
    ecg=electrocardiogram()
    Fs=360
    dt=1/Fs
    t=np.arange(3600)*dt
    x=ecg[0:3600]  
    drawEMD()
  
def drawEMD():
    global Fs,N,t,x,M,IMFs,IMF1s,res
    emd=EMD()
    emd.emd(x)
    IMFs,res=emd.get_imfs_and_residue()
    IMF1s=IMFs
    M=IMFs.shape[0]
    mPlot.clearFig(wn=M+3)
    mPlot.setValue2DXM(0,1/Fs,x,'#ffff00',ylow=-1.5,yhigh=1.5,cl=1)
    for i in range(M):
        mPlot.setValue2DXM(i+1,1/Fs,IMFs[i],'#00ff00',ylow=-1.5,yhigh=1.5,cl=1)
    mPlot.setValue2DXM(M+1,1/Fs,res,'#00ffff',ylow=-1.5,yhigh=1.5,cl=1)
    mPlot.setValue2DXM(M+2,1/Fs,x,'#ffeeaa',ylow=-1.5,yhigh=1.5,cl=1)

def setIEMD(v):
    global Fs,N,t,x,M,IMF1s,res
    M=IMF1s.shape[0]
    mPlot.clearFig(wn=M+3)
    mPlot.setValue2DXM(0,1/Fs,x,'#ffff00',ylow=-1.5,yhigh=1.5,cl=1)
    if (v==0): res=res*0;
    else:
        if v<=M: IMF1s[v-1]=IMF1s[v-1]*0        
    x1=res
    for i in range(M): x1=x1+IMF1s[i]
    for i in range(M):
        mPlot.setValue2DXM(i+1,1/Fs,IMF1s[i],'#00ff00',ylow=-1.5,yhigh=1.5,cl=1) 
    mPlot.setValue2DXM(M+1,1/Fs,res,'#00ffff',ylow=-1.5,yhigh=1.5,cl=1)
    mPlot.setValue2DXM(M+2,1/Fs,x1,'#ffeeaa',ylow=-1.5,yhigh=1.5,cl=1)
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=700
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-ECG信号EMD分解与重构')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,340,40,'#440000','#ffffff','ECG信号EMD分解与重构',20)
mPlot=dr.DRMonitor(win,20,70,1020,620)
mRBut=dr.DRHButtonGroup(win,370,25,600,30,'#000000','#ffffff','Err,IMF1,IMF2,IMF3,IMF4,IMF5,IMF6,IMF7,IMF8,IMF9,IMF10',12,0)
mBut=dr.DRButton(win,980,25,60,30,txt='重置')
mRBut.addCallBackSingle(setIEMD)
mBut.addCallBackSingle(setSignal)
#===============================
setSignal(0)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mBut)
mWidSize.addDRWidget(mRBut)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

