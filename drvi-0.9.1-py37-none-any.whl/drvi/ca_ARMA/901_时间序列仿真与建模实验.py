from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.arima_process import ArmaProcess
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
import numpy as np
import warnings
warnings.filterwarnings('ignore')

#生成模拟数据===
N=128
#ARMA(1,1)
ar = np.array([1,0.7])
ma = np.array([1,-0.1])
dta=ArmaProcess(ar, ma).generate_sample(nsample=N)
#添加非稳定性项
dta=dta+np.arange(N)*0.01

#显示用于定阶的acf和pacf图
fig,ax=plt.subplots(nrows=3,ncols=1)
ax[0].plot(dta)
plot_acf(dta,ax=ax[1]);
plot_pacf(dta,ax=ax[2]);

#==稳定性检验
s=adfuller(dta)
print(s)

#==模型拟合
res = ARIMA(dta, order=(1, 1, 1)).fit()

#==预测===
df_test=res.predict(start=0,end=128+32)
fig=plt.figure()
plt.plot(dta)
plt.plot(df_test)
plt.show()
