#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import tkinter as tk
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller as ADF
from statsmodels.tsa.arima_process import ArmaProcess
from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa
from threading import Thread
import warnings
warnings.filterwarnings('ignore')

#=================================================
def getData(v):
    global dta,N
    if v==0:
        data = sm.datasets.sunspots.load_pandas().data
        dta = pd.Series(data['SUNACTIVITY'].values.squeeze())
    if v==1:
        ar = np.array([1,0.9])
        ma = np.array([1])
        dta=ArmaProcess(ar, ma).generate_sample(nsample=300)
        dta=pd.Series(dta)
    if v==2:
        ar = np.array([1])
        ma = np.array([1,0.9])
        dta=ArmaProcess(ar, ma).generate_sample(nsample=300)
        dta=pd.Series(dta)
    if v==3:
        ar = np.array([1,-0.75, 0.25])
        ma = np.array([1,0.65, 0.35])
        dta=ArmaProcess(ar, ma).generate_sample(nsample=300)
        dta=pd.Series(dta)
    N=len(dta)
    mPlot.setValue2DX(1,dta)
    stable()
    acfpacf()
    initfitData()

def stable():
    global dta,N
    dta1=dta.diff()
    dta2=dta1.diff()
    mPlot1.clearFig()
    mPlot1.setValue2DXM(0,1,dta,cl=1)
    mPlot1.setValue2DXM(1,1,dta1,cl=1)
    mPlot1.setValue2DXM(2,1,dta2,cl=1)
    s=sm.tsa.stattools.adfuller(dta.dropna(how='all'))
    s1=sm.tsa.stattools.adfuller(dta1.dropna(how='all'))
    s2=sm.tsa.stattools.adfuller(dta2.dropna(how='all'))
    S='原信号：'+str(s)+'\n差分信号:'+str(s1)+'\n二次差分:'+str(s2)
    mText1.setValueString(S)

def acfpacf():
    global dta,N
    fig,ax=plt.subplots(2,1)
    plot_acf(dta,ax=ax[0]);
    plot_pacf(dta,ax=ax[1]);
    mFigure1.setValueFig(fig)

def fitData(v):
    global dta,N,res
    p=mEntry1.getValueSingle()
    d=mEntry2.getValueSingle()
    q=mEntry3.getValueSingle()
    res=ARIMA(dta,order=(p,d,q)).fit()
    dta1=res.predict(start=np.min(dta.index),end=np.max(dta.index)+64)    
    S=str(res.params)
    mText2.setValueString(S)
    mText12.setValueString(S)
    fig,ax=plt.subplots(3,1)
    ax[0].plot(dta);
    ax[0].plot(dta1);
    res.resid.plot(ax=ax[1])
    res.resid.plot(kind='kde',ax=ax[2])    
    mFigure2.setValueFig(fig)

def initfitData():
    global dta,N,res
    mText2.setValueString('')
    mText12.setValueString('')    
    fig,ax=plt.subplots(3,1)
    ax[0].plot(dta);
    mFigure2.setValueFig(fig)
    fig,ax=plt.subplots(1,1)
    plt.plot(np.zeros(256))    
    mFigure3.setValueFig(fig)
    mText3.setValueString('')
    fig,ax=plt.subplots(1,1)
    plt.plot(np.zeros(256))    
    mFigure4.setValueFig(fig)   

def drawSpectrum(v):
    global dta,N,res
    if len(mText12.getValueString())<2: return; 
    ar=res.polynomial_ar
    ma=res.polynomial_ma
    w, h = signal.freqz(ma,ar,512)
    fig,ax=plt.subplots(1,1)
    plt.plot(abs(h))
    mFigure3.setValueFig(fig)


def doBIC():
    global dta,N,res,hl
    d=mEntry22.getValueSingle()
    bic=np.zeros(100)
    K=0
    S=''
    for p in range(10):
        for q in range(10):
            res=ARIMA(dta,order=(p,d,q)).fit()
            bic[K]=res.bic
            K=K+1
            S=str(K)+','+str(p)+','+str(q)+': '+str(res.bic)+'\n'+S
            mText3.setValueString(S)
    fig,ax=plt.subplots(1,1)
    plt.plot(bic)
    mFigure4.setValueFig(fig)
    win.mainloop()

def setBIC(v):
    global dta,N,res,hl
    hl=Thread(target=doBIC)
    hl.start()
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-ARIMA时间序列建模分析')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','ARIMA时间序列建模分析',20) 
mBut=dr.DRHButtonGroup(win,460,25,580,36,txt='太阳黑子,AR1模拟数据,MA1模拟数据,ARMA22模拟数据')
mTab=dr.DRNoteBook(win,20,75,1020,590,txt='原始数据曲线,稳定性检测,ACF/PACF曲线,BIC定阶,ARIMA拟合,模型谱估计')
mPlot=dr.DRPlot(mTab.win[0],10,10,998,540)
mPlot1=dr.DRMonitor(mTab.win[1],10,10,998,430,wn=3)
mText1=dr.DRText(mTab.win[1],10,450,998,100,fsize=10)
mFigure1=dr.DRFigure(mTab.win[2],10,10,998,540,tight=True)
mBut1=dr.DRButton(mTab.win[4],10,10,180,36,txt='模型拟合(p,d,q)')
mEntry1=dr.DREntry(mTab.win[4],10,60,60,30,txt='8')
mEntry2=dr.DREntry(mTab.win[4],70,60,60,30,txt='1')
mEntry3=dr.DREntry(mTab.win[4],130,60,60,30,txt='2')
mText2=dr.DRText(mTab.win[4],10,100,180,440,fsize=10)
mFigure2=dr.DRFigure(mTab.win[4],200,10,798,540,tight=True)
mBut2=dr.DRButton(mTab.win[5],10,10,180,36,txt='模型谱估计')
mText12=dr.DRText(mTab.win[5],10,60,180,480,fsize=10)
mFigure3=dr.DRFigure(mTab.win[5],200,10,798,540,tight=True)
mBut3=dr.DRButton(mTab.win[3],10,10,180,36,txt='BIC收索(p<10,d,q<10)')
mEntry21=dr.DREntry(mTab.win[3],10,60,60,30,txt='<10')
mEntry22=dr.DREntry(mTab.win[3],70,60,60,30,txt='1')
mEntry23=dr.DREntry(mTab.win[3],130,60,60,30,txt='<10')
mText3=dr.DRText(mTab.win[3],10,100,180,440,fsize=10)
mFigure4=dr.DRFigure(mTab.win[3],200,10,798,540,tight=True)
#===============================
mBut.addCallBackSingle(getData)
mBut1.addCallBackSingle(fitData)
mBut2.addCallBackSingle(drawSpectrum)
mBut3.addCallBackSingle(setBIC)
#===============================
getData(0)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mTab)
mWidSize.addDRWidget(mBut)
mWidSize.addDRWidget(mPlot1)
mWidSize.addDRWidget(mText1)
mWidSize.addDRWidget(mFigure1)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mEntry1)
mWidSize.addDRWidget(mEntry2)
mWidSize.addDRWidget(mEntry3)
mWidSize.addDRWidget(mText2)
mWidSize.addDRWidget(mFigure2)
mWidSize.addDRWidget(mBut2)
mWidSize.addDRWidget(mText12)
mWidSize.addDRWidget(mFigure3)
mWidSize.addDRWidget(mBut3)
mWidSize.addDRWidget(mEntry21)
mWidSize.addDRWidget(mEntry22)
mWidSize.addDRWidget(mEntry23)
mWidSize.addDRWidget(mText3)
mWidSize.addDRWidget(mFigure4)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

