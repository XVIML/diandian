#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import tkinter as tk
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller as ADF
from statsmodels.tsa.arima_process import ArmaProcess
from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa
from threading import Thread
import warnings
warnings.filterwarnings('ignore')

#=================================================
def getData(v):
    global dta,N,Fs
    if v==0:
        st=0
        Fs=1
        data = sm.datasets.sunspots.load_pandas().data
        dta = pd.Series(data['SUNACTIVITY'].values.squeeze())
    if v==1:
        st=1
        N=300; Fs=5120; dt=1/Fs
        t=np.arange(N)*dt
        x1=np.sin(2*np.pi*150*t)
        x2=0.4*np.sin(2*np.pi*400*t)
        x3=0.4*np.sin(2*np.pi*800*t)
        x4=0.1*np.random.randn(N)
        x=x1+x2+x3+x4
        dta=pd.Series(x)
    N=len(dta)
    mPlot.setValue2DX(1,dta)
    initfitData()
    drawSpectrum()
    mTab.setPage(0)
    

def setBIC(v):
    global st,dta,N,res,hl
    e=np.zeros(64)
    b=np.zeros(64)
    S=''
    for p in range(64):
        res,err=sm.regression.linear_model.burg(dta,order=p+1)
        e[p]=err
        b[p]=np.log(err)+(p+1+1)*np.log(N)/N
        S=S+str(p+1)+': '+str(b[p])+'\n'
        mText3.setValueString(S)
    fig,ax=plt.subplots(1,1)
    plt.plot(b)
    mFigure4.setValueFig(fig)

def initfitData():
    global dta,N,Fs
    mText3.setValueString('')
    fig,ax=plt.subplots(1,1)
    plt.plot(np.zeros(256))    
    mFigure4.setValueFig(fig)
    mPlot1.setXlim(0,Fs/2)
    mPlot2.setXlim(0,Fs/2)
    Z=np.zeros((512,64))
    tt=np.arange(64)
    ff=np.arange(512)
    mwaterFall.setValue3D(tt,ff,Z) 

def drawSpectrum():
    global dta,N,Fs
    fftA=np.abs(np.fft.rfft(dta))
    f=np.arange(len(fftA))*(Fs/N)
    mPlot1.setValue2D(f,fftA)
    res,err=sm.regression.linear_model.burg(dta,order=64)
    ar=np.append(1,-res)
    w, h = signal.freqz(1,ar,5000)
    w=(Fs/2)*(w/np.pi)
    mPlot2.setValue2D(w,np.abs(h))
        
def setView(v):
    global dta,N,Fs
    Fs2=Fs/2;
    v1=mHSlider1.getValueSingle()/100
    v2=mHSlider2.getValueSingle()/100
    if v1>v2: v1=v2-0.01*v2
    mPlot1.setXlim(v1*Fs2,v2*Fs2)
    mPlot2.setXlim(v1*Fs2,v2*Fs2)
    
def setOrderSpec(v):
    global st,dta,N,res,hl
    M=64
    Z=np.zeros((512,M))
    for p in range(M):
        res,err=sm.regression.linear_model.burg(dta,order=p+1)
        ar=np.append(1,-res)
        w, h = signal.freqz(1,ar,512)
        Z[:,p]=np.abs(h)
    ff=(Fs/2)*(w/np.pi)
    tt=np.arange(M)
    mwaterFall.setValue3D(tt,ff,Z)    
    
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-高阶AR模型频谱估计')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','高阶AR模型频谱估计',20) 
mBut=dr.DRHButtonGroup(win,740,25,300,36,txt='太阳黑子,三频模拟数据')
mTab=dr.DRNoteBook(win,20,75,1020,590,txt='原始数据曲线,FFT谱和AR模型谱,AR模型BIC定阶,AR阶次谱阵')
mPlot=dr.DRPlot(mTab.win[0],10,10,998,540)
mPlot1=dr.DRPlot(mTab.win[1],10,10,998,250)
mPlot2=dr.DRPlot(mTab.win[1],10,260,998,250)
mHSlider1=dr.DRHSlider(mTab.win[1],30,520,480,20,val=0)
mHSlider2=dr.DRHSlider(mTab.win[1],530,520,480,20,val=100)
mBut3=dr.DRButton(mTab.win[2],10,10,180,36,txt='BIC收索(p<64)')
mText3=dr.DRText(mTab.win[2],10,60,180,480,fsize=10)
mFigure4=dr.DRFigure(mTab.win[2],200,10,798,540,tight=True)
mwaterFall=dr.DRwaterFall(mTab.win[3],10,10,998,540,'#113344','#000000','#ffffff','#00eeff',0.3,0.1,0.1,0,0)
mBut4=dr.DRButton(mTab.win[3],890,25,100,30,txt='计算阶次谱')
#===============================
mBut.addCallBackSingle(getData)
mBut3.addCallBackSingle(setBIC)
mBut3.addCallBackSingle(setOrderSpec)
mHSlider1.addCallBackSingle(setView)
mHSlider2.addCallBackSingle(setView)
mBut4.addCallBackSingle(setOrderSpec)
#===============================
getData(0)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mTab)
mWidSize.addDRWidget(mBut)
mWidSize.addDRWidget(mBut3)
mWidSize.addDRWidget(mText3)
mWidSize.addDRWidget(mFigure4)
mWidSize.addDRWidget(mPlot1)
mWidSize.addDRWidget(mPlot2)
mWidSize.addDRWidget(mHSlider1)
mWidSize.addDRWidget(mHSlider2)
mWidSize.addDRWidget(mwaterFall)
mWidSize.addDRWidget(mBut4)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

