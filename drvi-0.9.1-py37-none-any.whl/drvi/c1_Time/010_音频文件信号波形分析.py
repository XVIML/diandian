#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================

import tkinter as tk
import tkinter.messagebox as msgbox
from tkinter import filedialog
from tkinter import colorchooser
from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt
from pylab import mpl
from matplotlib import cm
import numpy as np
import librosa
import drvi.drviDSP as dsp
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa


#==Event response function of controls====
def setValueSingle(v):
    global Fs,N,CH,data
    mfile=filedialog.askopenfilename(title="选择文件",filetypes=(("MP3 files", "*.mp3"),("WAV files", "*.wav"),("all files", "*.*")))
    if not mfile: return 1
    openFile(mfile)

def openFile(mfile):
    global Fs,N,CH,data
    data,Fs=librosa.load(mfile,mono=True,sr=None)
    N=len(data);T=N/Fs    
    mPlotWave.setValue2DX(1/Fs,data)
    mPlotWave.setXlim(0,T)
    mTxt1.setValueString('')
    myWorking()

def setLength(v):
    global mLength
    if v==0: mLength=1024
    if v==1: mLength=2048
    if v==2: mLength=4096
    if v==3: mLength=8192
    if v==4: mLength=16384
    if v==5: mLength=32768
    if v==6: mLength=64535
    myWorking()
    
def setPos(v):
    global mPosition
    mPosition=v
    myWorking()

def setMove(v):
    global N,mLength,mPosition,mHSlider1
    if N==0: return;
    if v==201: d=-mLength/6
    if v==202: d=mLength/6
    d=100*d/N
    mPosition=mPosition+d
    if mPosition<0: mPosition=0
    if mPosition>100: mPosition=100
    mHSlider1.setValueSingle(mPosition)
    myWorking()

def myWorking():
    global Fs,N,CH,data,xdata,mPosition,mLength
    if N==0: return;
    K=int(mPosition*0.01*N)
    if K<0: K=0    
    xdata=data[K:K+mLength]
    mPlotWave1.setValue2DX(1/Fs,xdata)
    T=mLength/Fs
    mPlotWave1.setXlim(0,T)        

def setPlay(v):
    global Fs,N,CH,data,mPosition,mLength,pObj;
    if N==0: return;
    if v==0: pObj=sa.play(1,Fs,data,0)
    if v==1: pObj.stop()
    
def setAmplify(v):
    global Fs,N,CH,data,xdata,mPosition,mLength
    s=''
    T=dsp.findPeriod(Fs,len(xdata),xdata)
    if T>0: s=s+'频率='+format(1/T,'.2f')+'Hz'
    pp=np.max(xdata)-np.min(xdata)
    s=s+',  峰峰值:'+format(pp,'.2f')
    R=np.sqrt(np.sum(xdata**2)/len(xdata))
    s=s+',  有效值:'+format(R,'.2f')
    std=np.std(xdata)
    s=s+',  方差:'+format(std,'.2f')
    M=np.mean(xdata)
    s=s+',  均值:'+format(M,'.2f')
    kk=(np.sum(xdata**4)/len(xdata))/pow(R,4)
    s=s+',  峭度:'+format(kk,'.2f')    
    mTxt1.setValueString(s)

def setTime(v):
    global Fs,N,CH,data,xdata,mPosition,mLength,pObj;
    if Fs==0:
        mTimer2.setValueSingle(1)
        return;
    T=N/Fs
    v=v/1000
    if v>T:
        pObj.stop()
        mTimer2.setValueSingle(1)
    mPosition=100*v/T
    mHSlider1.setValueSingle(mPosition)
    myWorking()

def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)
    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1100
winHeightCur=670
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-WAV音乐文件信号波形浏览')

#==Layout of controls=====================
mL1=dr.DRLabel(win,20,35,500,40,'#440000','#ffffff','WAV文件信号波形浏览与分析',20)
mBut1=dr.DRButton(win,660,40,100,36,'#003355','#eeee00','打开文件',12,101)
mOMenu1=dr.DROptionMenu(win,770,40,100,36,'#003355','#eeee00','1024,2048,4096,8192,16384,32768,64535',11,3)
mPlotWave=dr.DRPlot(win,20,130,1060,250,'','#113344','#000000','#ffffff','#00eeff','#ffff00',0,0,-1,1,0,0)
mPlotWave1=dr.DRPlot(win,20,380,1060,250,'','#113344','#000000','#ffffff','#00eeff','#ffff00',0,0,-1,1,0,0)
mHSlider1=dr.DRHSlider(win,50,90,1010,30,'#444444','#004466','#008822',8,20,0,100,0)
mBut2=dr.DRButton(win,20,95,20,24,'#003355','#eeee00','<<',12,201)
mBut3=dr.DRButton(win,1060,95,20,24,'#003355','#eeee00','>>',12,202)
mHBut5=dr.DRHButtonGroup(win,880,40,200,36,'#003355','#ffffff','播放,停止',12,0)
mHBut5.addCallBackSingle(setPlay)
mBut9=dr.DRButton(win,900,370,60,26,'#005533','#ffffff','计算',12,400)
mTxt1=dr.DRLabel(win,80,400,700,30,'#000000','#00ffaa','',12)
mTimer2=dr.DRTimer(win,580,40,50,36,'#000000','#ffff00',100,11)
mTimer2.addCallBackSingle(setTime)
mHBut5.addCallBackSingle(mTimer2.setValueSingle)
mOMenu1.addCallBackSingle(setLength)
mBut1.addCallBackSingle(setValueSingle)
mHSlider1.addCallBackSingle(setPos)
mBut2.addCallBackSingle(setMove)
mBut3.addCallBackSingle(setMove)
mBut9.addCallBackSingle(setAmplify);
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mOMenu1)
mWidSize.addDRWidget(mPlotWave)
mWidSize.addDRWidget(mPlotWave1)
mWidSize.addDRWidget(mHSlider1)
mWidSize.addDRWidget(mBut2)
mWidSize.addDRWidget(mBut3)
mWidSize.addDRWidget(mHBut5)
mWidSize.addDRWidget(mBut9)
mWidSize.addDRWidget(mTxt1)
mWidSize.addDRWidget(mTimer2)
#==========================================
mPosition=0
mLength=8192
Fs=0
N=0
CH=0
data=0
xdata=0
pObj=0
mFile=mPath.getDRVIPath()+'\\dataset\\BGBird.mp3'
openFile(mFile)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

