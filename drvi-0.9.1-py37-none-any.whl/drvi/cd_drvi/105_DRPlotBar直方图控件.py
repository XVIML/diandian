#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#用户自定义的回调函数
def muserSingle(v):
    x=[0,1,2,3,4,5,6,7,8]
    A=[0,2,4,6,8,4,3,2,1]
    mP.setValue2D(x,A)
    

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入按钮控件
mB1=dr.DRButton(win,78,39,100,40,'#00aacc','#eeee00','Button',12,101)
#==插入PlotBar控件
mP=dr.DRPlotBar(win,70,105,700,210)
#==控件直连绑定
mB1.addCallBackSingle(muserSingle)
#==主程序循环
win.mainloop()
