#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#==用户自定义函数
def muserSingle1(v):
 x=v
 print(v) 

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入滑块控件
mHSlider1=dr.DRHSlider(win,77,49,260,30,'#444444','#880000','#008822',8,20,0,100,20)
#==直连绑定
mHSlider1.addCallBackSingle(muserSingle1)
#==主程序循环
win.mainloop()
