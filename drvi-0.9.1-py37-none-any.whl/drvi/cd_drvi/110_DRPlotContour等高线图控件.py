#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import numpy as np

#用户自定义的回调函数
def muserSingle3(v):
    x=np.linspace(-14,14,128)
    y=np.linspace(-14,14,128)
    [xSurf,ySurf]=np.meshgrid(x,y)
    r=np.sqrt(xSurf**2+ySurf**2)
    zSurf=np.sin(r).T/r
    mP3D.setValue3D(x,y,zSurf)
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入开关按钮控件
mButton1=dr.DRSwitch(win,50,42,80,40)
#==插入等高线图控件
mP3D=dr.DRPlotContour(win,200,20,640,480,'',0,0,0,64,'cool')
#==直连方式绑定
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
