#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入按钮控件
mN=dr.DRNoteBook(win,123,65,600,400,txt='P1,P2,P3')
#==在第一页插入按钮组控件
mB1=dr.DRHButtonGroup(mN.win[0],40,40,240,36,txt='A,B,C,D')
#==在第二页插入文本框控件
mE2=dr.DREntry(mN.win[1],40,40,100,30)
#==控件绑定
mB1.addCallBackSingle(mE2.setValueSingle)
#==主程序循环
win.mainloop()
