#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#用户自定义的回调函数
def muserSingle6(v):
    dx,yarray=mGen2.getArrayTwoX()
    mPlot4.setValue2DX(dx,yarray)
        
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入2个开关按钮控件
mButton1=dr.DRButton(win,32,40,100,40,txt='Run/Stop')
mButton5=dr.DRButton(win,27,257,100,40,txt='GetData')
#==插入信号发生器控件
mGen2=dsp.DRGenerator(F=200)
#==插入2个曲线控件
mPlot3=dr.DRPlot(win,159,34,700,159)
mPlot4=dr.DRPlot(win,151,217,700,180)
#=直连绑定
mButton1.addCallBackSingle(mGen2.setVSOnOff)
mButton5.addCallBackSingle(muserSingle6)
mGen2.addCallBack2D(mPlot3.setValue2D)
#==主程序循环
win.mainloop()
