#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#用户自定义的回调函数
def muserSingle(v):
    print(v)
    mSys.setVSType(v)
    dt,F=mSys.getValue2DXF()
    dt,y1=mSys.getValue2DXR(1)
    mPlot3.setValue2DX(dt,F)
    mPlot4.setValue2DX(dt,y1)    
      
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('1100x600')
win.config(bg="#ddeeee")
#==插入控件
mHBGr1=dr.DRHButtonGroup(win,30,19,280,36,txt='脉冲,阶跃,扫频,噪声')
mSys=dsp.DRTester(N=2048)
mPlot3=dr.DRPlot(win,27,76,700,210)
mPlot4=dr.DRPlot(win,26,307,700,210)
#==信号的直连绑定
mHBGr1.addCallBackSingle(muserSingle)
#==主程序循环
win.mainloop()
