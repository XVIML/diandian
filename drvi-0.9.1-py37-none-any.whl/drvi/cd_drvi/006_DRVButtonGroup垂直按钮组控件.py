import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入控件
mButton1=dr.DRVButtonGroup(win,40,44,100,100,val=1010)
mEntry2=dr.DREntry(win,198,44,100,30)
#==绑定控件
mButton1.addCallBackSingle(mEntry2.setValueSingle)
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
