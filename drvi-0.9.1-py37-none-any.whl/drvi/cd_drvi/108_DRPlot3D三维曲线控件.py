#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import numpy as np

#用户自定义的回调函数==========
def muserSingle3(v):
    Fs=5120
    dt=1.0/Fs
    N=4096
    t=np.arange(N)*dt
    z1=0.2*np.sin(2*np.pi*10*t)
    z2=0.3*np.sin(2*np.pi*15*t)
    y=np.ones(N)*0.6
    mP3D.setValue3D(t,2*t,z1,'#00aaaa')
    mP3D.addValue3D(t,y,z2,'#aa0000')     
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入控件
mP3D=dr.DRPlot3D(win,20,40,700,400)
#==直连方式绑定
muserSingle3(0)
#==主程序循环
win.mainloop()
