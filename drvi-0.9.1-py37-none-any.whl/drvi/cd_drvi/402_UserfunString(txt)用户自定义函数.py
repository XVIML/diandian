#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#==用户自定义函数
def muserString2(txt):
 tt=txt
 print(txt) 

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入文本框
mEntry1=dr.DREntry(win,74,55,100,30,'#ffffff','#000000','ABC',12)
#==直连绑定
mEntry1.addCallBackString(muserString2)
#==主程序循环
win.mainloop()
