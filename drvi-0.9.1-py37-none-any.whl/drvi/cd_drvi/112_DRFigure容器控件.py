#==引用的包
import tkinter as tk
import numpy as np
from scipy.fft import rfft,irfft
import matplotlib.pyplot as plt
import drvi.drviControlls as dr
#=====================
def muserSingle(v):
    global F
    F=F+100
    Fs=5120
    N=512
    t=np.arange(N)*(1/Fs)
    y=np.sin(2*np.pi*F*t)
    N2=int(N/2)
    A=np.abs(np.fft.rfft(y))/(N2)
    f=np.arange(N2+1)*(Fs/N);
    plt.close('all')
    fig,ax=plt.subplots(2,1)
    ax[0].plot(t,y)
    ax[1].plot(f,A)    
    mFigure.setValueFig(fig)  
    
#==Main Window=====================
win= tk.Tk()
win.geometry('1204x716')
win.config(bg="#ddeeee")
#==Layout of controls=================
mB1=dr.DRButton(win,20,20,100,30,'#00aacc','#eeee00','Button',12,101)
mFigure=dr.DRFigure(win,21,78,700,360,cb='#003355',cb1='#000000',cf='#ffffff',cf1='#009999',cf2='#ffff00',tight=False)
#=User defined data probe============
mB1.addCallBackSingle(muserSingle)
#==全局变量===
F=0
#==Main Loop=====================
win.mainloop()
