#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#用户自定义的回调函数
def muserSingle(v):
    global F
    Fs=5000
    N=512
    F=F+10
    t=np.arange(N)*(1/Fs)
    y=0.5*np.sin(2*np.pi*F*t)
    abc.setValue2DX(1/Fs,y)
    abin,pdf,cdf=abc.getPdfCdf()
    mSub.setValue2D1(t,y)
    mSub.setValue2D2(abin,pdf)
    mSub.setValue2D3(abin,cdf)    
       
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('1100x600')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,20,10,100,30,txt='Run/Stop')
#==插入概率密度和分布控件
abc=dsp.DRPdfCdf(ylow=-1,yhigh=1)
#==插入曲线显示控件
mSub=dr.DRSubPlot(win,20,50,950,500,N=3,M=1)
#==信号的直连绑定
mButton1.addCallBackSingle(muserSingle)
#==全局变量===
F=0
#==主程序循环
win.mainloop()
