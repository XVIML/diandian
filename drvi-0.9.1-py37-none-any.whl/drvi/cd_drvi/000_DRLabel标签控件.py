#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    mLabe.setValueString('Button Clicked !')
    txt=mLabe.getValueString()
    print(txt)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,50,42,100,40,txt='Run')
#==插入标签控件
mLabe=dr.DRLabel(win,221,42,200,30,fsize=16)
#==绑定用户回调函数
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
