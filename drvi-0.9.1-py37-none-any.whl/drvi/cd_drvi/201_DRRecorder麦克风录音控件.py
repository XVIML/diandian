#==引用的包
import tkinter as tk
import numpy as np
from scipy.fft import rfft,irfft
import drvi.drviControlls as dr
import drvi.drviAudio as drAudio

#用户自定义的回调函数
def muser2d(t,y):
    tArray=t
    yArray=y
    N=len(y)
    N2=int(N/2)
    Fs=1/t[1]
    df=Fs/N;
    A=np.abs(np.fft.rfft(y))/N2
    mPlot3.setValue2DX(tArray,yArray)
    mPlot4.setValue2DX(df,A)
    
        
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('1000x497')
win.config(bg="#ddeeee")
#==插入2个开关按钮控件
mButton1=dr.DRButton(win,32,40,100,40,txt='Run/Stop')
#==插入麦克风控件
mRecorder2=drAudio.DRRecorder(win,29,112,100,40)
#==插入2个曲线控件
mPlot3=dr.DRPlot(win,159,34,800,200)
mPlot4=dr.DRPlot(win,159,250,800,200)
#=直连绑定
mButton1.addCallBackSingle(mRecorder2.setVSOnOff)
mRecorder2.addCallBack2D(muser2d)
#==主程序循环
win.mainloop()
