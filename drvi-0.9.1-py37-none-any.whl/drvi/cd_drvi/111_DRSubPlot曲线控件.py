#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import numpy as np
from scipy.fftpack import fft,ifft

#用户自定义的回调函数
def muserSingle3(v):
    #==生成多频测试信号
    Fs=44100;
    N=2000;
    dt=1.0/Fs
    t=np.arange(N)*dt
    x1=np.sin(2*np.pi*200*t)
    x1=x1+0.33*np.sin(2*np.pi*600*t)
    x1=x1+0.2*np.sin(2*np.pi*1000*t)
    x1=x1+0.14*np.sin(2*np.pi*1400*t)
    #==计算信号的幅值谱    
    y2=np.abs(fft(x1))
    f=np.arange(int(N/2))*Fs/N;
    a2=2*y2[:int(N/2)]/N
    #==用Subplot显示幅值谱
    mSub.setValue2DX(1,f,a2)
    mSub.setValue2DX(2,f,a2)
    mSub.setValue2DX(3,f,a2)
    mSub.setValue2DX(4,f,a2)
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('1000x497')
win.config(bg="#ddeeee")
#==插入开关按钮控件
mButton1=dr.DRSwitch(win,50,22,80,40)
#==插入Subplot,2x2，plot,semix,semiy,loglog
mSub=dr.DRSubPlot(win,62,80,1000,400,N=2,M=2,style=[0,2,3,4])
#==直连方式绑定
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()


