#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#==用户自定义函数
def muserArrayTwoX(dx,yArray):
 print("data ready")

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入信号发生器
mGenerator1=dsp.DRGenerator(0,44100,4096,0.6,100,0,250)
#==插入按钮
mButton2=dr.DRButton(win,43,27,100,40,'#00aacc','#eeee00','Button',12,101)
#==直连绑定
mButton2.addCallBackSingle(mGenerator1.setVSOnOff)
mGenerator1.addCallBack2DX(muserArrayTwoX)
#==主程序循环
win.mainloop()
