#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    sizes = [30, 40, 20, 10]
    labels = ['A', 'B', 'C', 'D']
    mPie.setValue2DStringSingle(labels,sizes)
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入开关按钮控件
mButton1=dr.DRSwitch(win,50,42,80,40)
#==插入饼图控件
mPie=dr.DRPlotPie(win,152,63,300,300,'ABCD',['A','B','C','D','E','F'],[1,2,3,4,5,6])
#==直连方式绑定
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
