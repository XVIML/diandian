#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import drvi.drviDSP as dsp
import drvi.drviSimpleAudio as ply
import warnings
warnings.filterwarnings('ignore')

#用户自定义的回调函数
def muser2D(t,y):
    global cc
    cc=cc+1
    tArray=t
    yArray=y
    if cc==2:
        cc=0
        mPlot1.setValue2D(t,y)
        mPlot1.setYlim(-1,1)
        
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入3个按钮控件
mBut1=dr.DRButton(win,130,20,100,40,txt='Run/Stop')
mBut2=dr.DRButton(win,20,20,100,40,txt='SelectFile')
#==插入文本框控件
mEntry1=dr.DREntry(win,470,20,250,40)
#==插入WAV播放器
mPlayer=ply.DRPlay(win,350,20,100,40,'#00aacc','#eeee00',11)
#==插入2个曲线控件
mPlot1=dr.DRPlot(win,20,80,700,210)

#=直连绑定
mBut1.addCallBackSingle(mPlayer.setVSOnOff)
mBut2.addCallBackSingle(mPlayer.setSelectfile)
mPlayer.addCallBack2D(muser2D)
mPlayer.addCallBackStrFile(mEntry1.setValueString)
#=global=========
cc=0
#==主程序循环
win.mainloop()

