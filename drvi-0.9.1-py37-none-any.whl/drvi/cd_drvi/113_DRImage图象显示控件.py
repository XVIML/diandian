#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserString(txt):
    print(txt)
    mImg.setValueString(txt)
    

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入文件选择窗按钮
mButton1=dr.DRFileBut(win,50,42,100,40,txt='File')
#==插入图象显示控件
mImg=dr.DRImage(win,194,31,420,260)
#==直连绑定
mButton1.addCallBackString(muserString)
#==主程序循环
win.mainloop()
