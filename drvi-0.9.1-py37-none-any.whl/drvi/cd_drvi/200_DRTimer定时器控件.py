#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)
    mEntry3.setValueSingle(v)
        
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入开关按钮控件
mButton1=dr.DRButton(win,84,34,100,40,'#00aacc','#eeee00','Button',12,101)
#==插入定时器控件
mTimer2=dr.DRTimer(win,211,35,100,40,dt=200)
#==插入输入框控件
mEntry3=dr.DREntry(win,356,36,100,30)
#=直连绑定
mButton1.addCallBackSingle(mTimer2.setValueSingle)
mTimer2.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
