#==引用的包
import tkinter as tk
import drvi.drviControlls as dr
import numpy as np

#用户自定义的回调函数
def muserSingle3(v):
    r = np.arange(0, 2, 0.01)
    theta = 2 * np.pi * r
    mPolar.setValue2D(theta,r)
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入开关按钮控件
mButton1=dr.DRSwitch(win,50,42,80,40)
#==插入极坐标图控件
mPolar=dr.DRPlotPolar(win,225,124,300,300)
#==直连方式绑定
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
