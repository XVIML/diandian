#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle(v):
    global ff;    
    Fs=1000
    N=1000
    ff=ff+10
    t=np.arange(N)*(1/Fs)
    y1=np.sin(2*np.pi*ff*t)
    y2=np.sin(2*np.pi*2*ff*t)
    y3=np.sin(2*np.pi*3*ff*t)
    y4=np.sin(2*np.pi*5*ff*t)
    mPlot.setValue2DM(0,t,y1,'#00ff00',0,-1.5,1.5)
    mPlot.setValue2DM(1,t,y2,'#ffff00',0,-1.5,1.5)
    mPlot.setValue2DM(2,t,y3,'#ff88ff',0,-1.5,1.5)
    mPlot.setValue2DM(3,t,y4,'#00ffff',0,-1.5,1.5) 
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x497')
win.config(bg="#ddeeee")
ff=10
#==插入控件
mButton1=dr.DRButton(win,20,20,100,30,txt='Run')
mPlot=dr.DRMonitor(win,20,80,800,400,wn=4)
#==绑定用户回调函数
mButton1.addCallBackSingle(muserSingle)
#==global var===
ff=0
#==主程序循环
win.mainloop()
