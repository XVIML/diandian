#==引用的包
import tkinter as tk
import numpy as np
from scipy import signal
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    Fs=5120;
    N=50000;
    t=np.arange(N)*(1.0/Fs)
    y=np.sin(2*np.pi*(100+5*t*t)*t)    
    nft=1024; ovl=int(nft/2)
    ff,tt,Sxx=signal.spectrogram(y,Fs,nperseg=nft,noverlap=ovl)
    mArray.setValue3D(tt,ff,20*np.log10(Sxx))

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x497')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,20,20,100,30,txt='Run')
#==插入语谱图显示控件
mArray=dr.DRColormesh(win,20,60,800,400)
#==绑定用户回调函数
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
