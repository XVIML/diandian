#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserString3(txt):
    print(txt)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入文件选择窗按钮
mButton1=dr.DRFileBut(win,50,42,100,40,txt='File')
#==插入文本框控件
mEntry2=dr.DREntry(win,198,44,300,30,txt='')
#==直连绑定
mButton1.addCallBackString(mEntry2.setValueString)
mButton1.addCallBackString(muserString3)
#==主程序循环
win.mainloop()
