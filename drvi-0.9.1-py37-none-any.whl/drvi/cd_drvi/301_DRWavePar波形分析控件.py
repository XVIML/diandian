#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

def muserSingle(v):
    global F
    Fs=5000
    N=512
    F=F+10
    t=np.arange(N)*(1/Fs)
    y=0.5*np.sin(2*np.pi*F*t)
    mPlot.setValue2D(t,y)
    mWavePar3.setValue2DX(1/Fs,y)
    par=mWavePar3.getArrayWavePar()
    print(par) 

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,56,14,100,40)
#==插入波形分析控件
mWavePar3=dsp.DRWavePar()
#==插入曲线控件
mPlot=dr.DRPlot(win,58,91,700,210)
#=直连绑定
mButton1.addCallBackSingle(muserSingle)
#==全局变量===
F=0
#==主程序循环
win.mainloop()

