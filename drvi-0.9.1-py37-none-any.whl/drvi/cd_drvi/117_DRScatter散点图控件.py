#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr

def userFun(v):
    global ff;    
    Fs=1000
    N=1000
    ff=ff+2
    t=np.arange(N)*(1/Fs)
    y=np.sin(2*np.pi*ff*t)
    mP3.setValue3DC(t,y,y)    

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入按钮控件
mB1=dr.DRButton(win,78,39,100,40,'#00aacc','#eeee00','Button',12,101)
#==插入Scatter控件
mP3=dr.DRScatter(win,95,122,700,210)
#==控件直连绑定
mB1.addCallBackSingle(userFun)
#==global var===
ff=0
#==主程序循环
win.mainloop()
