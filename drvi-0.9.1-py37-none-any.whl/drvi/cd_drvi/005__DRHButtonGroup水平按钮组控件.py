#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入图标按钮控件
mButton1=dr.DRHButtonGroup(win,40,40,240,36,val=10)
#==插入文本框控件
mEntry2=dr.DREntry(win,350,44,100,30)
#==直连方式绑定文本框控件
mButton1.addCallBackSingle(mEntry2.setValueSingle)
#==绑定用户回调函数
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
