#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入弹出式菜单按钮控件
mOpt=dr.DROptionMenu(win,113,205,100,40,val=2)
#==插入标签控件
mLab=dr.DRLabel(win,221,42,200,30,fsize=16)
#==绑定用户回调函数
mOpt.addCallBackSingle(muserSingle3)
mOpt.addCallBackString(mLab.setValueString)
#==主程序循环
win.mainloop()
