#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入列表选择框控件
mList=dr.DRListBox(win,111,88,140,100,val=2)
#==插入标签控件
mLab=dr.DRLabel(win,221,42,200,30,fsize=16)
#==绑定用户回调函数
mList.addCallBackSingle(muserSingle3)
mList.addCallBackSingle(mLab.setValueSingle)
#==主程序循环
win.mainloop()
