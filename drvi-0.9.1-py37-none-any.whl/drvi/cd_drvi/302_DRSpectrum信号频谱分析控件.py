#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

def muserSingle(v):
    global F
    Fs=5000
    N=512
    F=F+10
    t=np.arange(N)*(1/Fs)
    y=0.5*np.sin(2*np.pi*F*t)
    mPlot4.setValue2D(t,y)
    mSpectrum3.setValue2DX(1/Fs,y)
    ff,AA=mSpectrum3.getArrayTwoAmpA()
    mPlot5.setValue2D(ff,AA)
       
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x600')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,53,29,100,40,txt='Run/Stop')
#==插入频谱分析控件
mSpectrum3=dsp.DRSpectrum()
#==插入曲线显示控件
mPlot4=dr.DRPlot(win,50,91,700,210)
mPlot5=dr.DRPlot(win,49,319,700,210)
#==信号的直连绑定
mButton1.addCallBackSingle(muserSingle)
#==全局变量===
F=0
#==主程序循环
win.mainloop()
