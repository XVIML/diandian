#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    mL.setItems(0,0,'A')
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入按钮控件
mButton1=dr.DRButton(win,50,42,100,40,txt='Run')
#==插入列表控件
mL=dr.DRList(win,302,83,300,90,N=2,M=3)
#==绑定用户回调函数
mButton1.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
win.mainloop()
