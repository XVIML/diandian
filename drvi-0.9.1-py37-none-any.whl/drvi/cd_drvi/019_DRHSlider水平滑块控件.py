#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入水平滑块控件
mS=dr.DRHSlider(win,222,86,260,30,val=10)
#==插入标签控件
mLab=dr.DRLabel(win,221,42,200,30,fsize=16)
#==绑定用户回调函数
mS.addCallBackSingle(muserSingle3)
mS.addCallBackSingle(mLab.setValueSingle)
#==主程序循环
win.mainloop()
