#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    x=mD1.getValueSingle()
    print(x)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入数显控件
mD1=dr.DRDigital(win,230,173,100,36,val=0)
#==插入滑块控件
mS2=dr.DRHSlider(win,99,66,260,30,val=0)
#==绑定用户回调函数
mS2.addCallBackSingle(mD1.setValueSingle)
mS2.addCallBackSingle(muserSingle3)
#==主程序循环
win.mainloop()
