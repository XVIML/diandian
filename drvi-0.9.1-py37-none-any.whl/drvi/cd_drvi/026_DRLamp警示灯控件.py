#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入警示灯控件
mL1=dr.DRLamp(win,448,114,60,60,val=0)
#==插入开关组控件
mB2=dr.DRHButtonGroup(win,60,127,240,36,txt='绿,黄,红')
#=直连绑定
mB2.addCallBackSingle(mL1.setValueSingle)
#==主程序循环
win.mainloop()
