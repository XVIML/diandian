#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle(v):
    global F
    Fs=5000
    N=512
    F=F+10
    t=np.arange(N)*(1/Fs)
    y=0.5*np.sin(2*np.pi*F*t)
    mPlot.setValue2D(t,y)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('900x500')
win.config(bg="#ddeeee")
#==插入按钮控件
mB1=dr.DRButton(win,78,39,100,40,'#00aacc','#eeee00','Button',12,101)
#==插入Plot控件
mPlot=dr.DRPlot(win,95,122,700,210,xlow=0,xhigh=0.05)
#==控件直连绑定
mB1.addCallBackSingle(muserSingle)
#==全局变量===
F=0
#==主程序循环
win.mainloop()
