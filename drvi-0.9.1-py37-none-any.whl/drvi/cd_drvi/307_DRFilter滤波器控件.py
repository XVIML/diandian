#==引用的包
import tkinter as tk
import numpy as np
import drvi.drviControlls as dr
import drvi.drviDSP as dsp

#用户自定义的回调函数
def muserSingle(v):
    global f1
    Fs=5120;
    N=1024;
    t=np.arange(N)*(1.0/Fs)
    x=np.sin(2*np.pi*(100+2000*t)*t)
    mPlot1.setValue2D(t,x)
    abc.setType(2)
    f2=f1+200
    abc.setBand(f1,f2)
    abc.setValue2DX(1/Fs,x)
    dt,x1=abc.getValue2DX()
    mPlot2.setValue2DX(dt,x1)
    f1=f1+100
    if f1>800: f1=800
    
#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('1100x600')
win.config(bg="#ddeeee")
#==插入控件
mButton1=dr.DRButton(win,20,10,100,30,txt='Run')
abc=dsp.DRFilter()
mPlot1=dr.DRPlot(win,20,60,800,210)
mPlot2=dr.DRPlot(win,20,300,800,210)
#==信号的直连绑定
mButton1.addCallBackSingle(muserSingle)
#==Global
f1=0
#==主程序循环
win.mainloop()

