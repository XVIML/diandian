#==引用的包
import tkinter as tk
import drvi.drviControlls as dr

#用户自定义的回调函数
def muserSingle3(v):
    print(v)

#==创建Tkinter GUI窗口
win= tk.Tk()
win.geometry('816x497')
win.config(bg="#ddeeee")
#==插入数字调节钮控件
mDig=dr.DRSpinBox(win,50,40,120,32,val=5)
#==插入标签控件
mLab=dr.DRLabel(win,221,42,200,30,fsize=16)
#==绑定用户回调函数
mDig.addCallBackSingle(muserSingle3)
mDig.addCallBackSingle(mLab.setValueSingle)
#==主程序循环
win.mainloop()
