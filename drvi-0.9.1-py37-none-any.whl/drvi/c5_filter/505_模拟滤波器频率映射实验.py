import control as ct
import numpy as np
import matplotlib.pyplot as plt

#==加载ct库
s = ct.tf('s')

#定义原型低通滤波器
mLow='1/(s**3+2*s**2+2*s+1)';
mSys='sys='+mLow
exec(mSys)
print(sys)
plt.figure()
ct.bode_plot(sys)

#低通到高通,wc=10
mHigh=mLow;
mHigh=mHigh.replace('s','(10/s)')
mSys='sys='+mHigh
exec(mSys)
print(sys)
plt.figure()
ct.bode_plot(sys)

#低通到带通,wl=1,wh=10,
mPass=mLow;
mPass=mPass.replace('s','((s**2+1*10)/(s*(10-1)))')
mSys='sys='+mPass
exec(mSys)
print(sys)
plt.figure()
ct.bode_plot(sys)

#低通到带阻,wl=1,wh=10,
mStop=mLow;
mStop=mStop.replace('s','((s*(8-4))/(s**2+4*8))')
mSys='sys='+mStop
exec(mSys)
print(sys)
plt.figure()
ct.bode_plot(sys)
plt.show()
