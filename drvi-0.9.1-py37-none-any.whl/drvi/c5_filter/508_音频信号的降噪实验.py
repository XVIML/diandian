#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import tkinter as tk
from tkinter import filedialog
import numpy as np
import librosa.display
import matplotlib.pyplot as plt
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa
import drvi.drKillNoise as kNoise
import drvi.drviDSP as dsp
#==================================================    
def setFile(v):
    global Fs,N,CH,data 
    mfile=filedialog.askopenfilename(title="选择文件",filetypes=(("MP3 files", "*.mp3"),("WAV files", "*.wav"),("all files", "*.*")))
    if not mfile: return 1
    openFile(mfile)

def openFile(mfile):
    global Fs,N,data,data1 
    data, Fs = librosa.load(mfile,mono=True,sr=None)
    N=len(data);
    data1=data
    drawTF(0,Fs,N,data)   

def setReset(v):
    global Fs,N,data,data1 
    data1=data
    drawTF(0,Fs,N,data)   
   
def setFilter(v):
    global Fs,N,CH,data,data1 
    data1= kNoise.removeStationaryNoise(data1,Fs)  
    drawTF(1,Fs,N,data1)

def setFilter1(v):
    global Fs,N,CH,data,data1
    f1=mEntry1.getValueSingle()
    f2=mEntry2.getValueSingle()
    abc=dsp.DRFilter()
    abc.setBand(f1,f2)
    abc.setValue2DX(1/Fs,data1)
    dt,data1=abc.getValue2DX()    
    drawTF(1,Fs,N,data1)
    
def drawTF(k,Fs,N,data):
    T=N/Fs;
    y = librosa.amplitude_to_db(np.abs(librosa.stft(data)), ref=np.max)
    plt.close('all')
    fig, ax = plt.subplots(1,1)
    img=librosa.display.specshow(y, sr=Fs, x_axis='time', y_axis='log')
    plt.ylim(128, 16000)
    fig.colorbar(img, ax=ax, format="%+2.f dB")
    if k==0:
        mPlotWave.setValue2DX(1/Fs,data)
        mPlotWave.setXlim(0,T)
        mSpec.setValueFig(fig)
        mPlotWave1.setValue2DX(1/Fs,data)
        mPlotWave1.setXlim(0,T)
        mSpec1.setValueFig(fig)        
    if k==1:
        mPlotWave1.setValue2DX(1/Fs,data1)
        mPlotWave1.setXlim(0,T)
        mSpec1.setValueFig(fig)   
    
def setPlay(v):
    global Fs,N,CH,data,pObj;
    if N==0: return;
    if v==0: pObj=sa.play(1,Fs,data,0)
    if v==1: pObj.stop()

def setPlay1(v):
    global Fs,N,CH,data1,pObj;
    if N==0: return;
    if v==0: pObj=sa.play(1,Fs,data1,0)
    if v==1: pObj.stop()

def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)
    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1260
winHeightCur=700
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-音频信号的降噪实验')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,35,300,40,'#440000','#ffffff','音频信号的降噪实验',20)
mBut1=dr.DRButton(win,340,40,100,36,'#003355','#eeee00','打开文件',12,101)
mBut1.addCallBackSingle(setFile)
mHBut5=dr.DRHButtonGroup(win,440,40,140,36,'#003355','#ffffff','播放,停止',12,0)
mHBut5.addCallBackSingle(setPlay)
mBReset=dr.DRButton(win,580,40,80,36,'#003355','#eeee00','复位',12,101)
mBReset.addCallBackSingle(setReset)
mBand=dr.DRButton(win,690,40,100,36,'#003355','#eeee00','带通滤波',12,101)
mEntry1=dr.DREntry(win,790,40,80,36,'#ffffff','#000000','200',12)
mEntry2=dr.DREntry(win,870,40,90,36,'#ffffff','#000000','6000',12)
mBand.addCallBackSingle(setFilter1)
mBut12=dr.DRButton(win,960,40,100,36,'#003355','#eeee00','谱减法滤波',12,101)
mBut12.addCallBackSingle(setFilter)
mHBut51=dr.DRHButtonGroup(win,1060,40,160,36,'#003355','#ffffff','播放,停止',12,0)
mHBut51.addCallBackSingle(setPlay1)
mPlotWave=dr.DRPlot(win,20,90,600,150,'','#113344','#000000','#ffffff','#00eeff','#00ff00',0,0,-1,1,0,0)
mPlotWave1=dr.DRPlot(win,620,90,600,150,'','#113344','#000000','#ffffff','#00eeff','#00ff00',0,0,-1,1,0,0)
mSpec=dr.DRFigure(win,20,250,600,430,cb='#113344',cb1='#000000',cf='#ffffff',cf1='#009999',cf2='#ffff00')
mSpec1=dr.DRFigure(win,620,250,600,430,cb='#113344',cb1='#000000',cf='#ffffff',cf1='#009999',cf2='#ffff00')
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mHBut5)
mWidSize.addDRWidget(mBut12)
mWidSize.addDRWidget(mHBut51)
mWidSize.addDRWidget(mPlotWave)
mWidSize.addDRWidget(mPlotWave1)
mWidSize.addDRWidget(mBReset)
mWidSize.addDRWidget(mBand)
mWidSize.addDRWidget(mEntry1)
mWidSize.addDRWidget(mEntry2)
mWidSize.addDRWidget(mBut12)
mWidSize.addDRWidget(mSpec)
mWidSize.addDRWidget(mSpec1)
#============================
mfile=mPath.getDRVIPath()+'\\dataset\\NoiseBird.mp3'
openFile(mfile)    
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

