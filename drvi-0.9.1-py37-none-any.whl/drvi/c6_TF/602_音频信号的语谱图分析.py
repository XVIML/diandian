#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================

import tkinter as tk
from tkinter import filedialog
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
import librosa.display
import librosa
import drvi.drviDSP as dsp
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa

#==Event response function of controls====
def setValueSingle(v):
    mfile=filedialog.askopenfilename(title="选择文件",filetypes=(("MP3 files", "*.mp3"),("WAV files", "*.wav"),("all files", "*.*")))
    if not mfile: return 1
    openFile(mfile)

def setDemo(v):
    if v==0:
        mfile=mPath.getDRVIPath()+'\\dataset\\BGBird.mp3'
    if v==1:
        mfile=mPath.getDRVIPath()+'\\dataset\\oneTwoThree.mp3'
    if v==2:
        mfile=mPath.getDRVIPath()+'\\dataset\\TF_Giuta_DoRuiMe.mp3'        
    openFile(mfile)
    
def openFile(mfile):
    global Fs,N,data
    data, Fs = librosa.load(mfile,mono=True,sr=None)
    N=len(data); T=N/Fs
    mPlotWave.setValue2DX(1/Fs,data)    
    mPlotWave.setXlim(0,T)
    doSpec(0)
    
def doSpec(v):
    v=mOpt.getValueSingle()
    if v==0: setSpecGram()
    if v==1: setLogSpecGram()
    if v==2: setMelSpecGram()
        
def setSpecGram():
    global Fs,N,CH,data
    y = librosa.amplitude_to_db(np.abs(librosa.stft(data)), ref=np.max)
    plt.close('all')
    fig, ax = plt.subplots(1,1)
    img=librosa.display.specshow(y, sr=Fs, x_axis='time', y_axis='linear')
    plt.ylim(10, 8500)
    fig.colorbar(img, ax=ax, format="%+2.f dB")
    mPlotArray.setValueFig(fig)

def setLogSpecGram():
    global Fs,N,CH,data
    y = librosa.amplitude_to_db(np.abs(librosa.stft(data)), ref=np.max)
    plt.close('all')
    fig, ax = plt.subplots(1,1)
    img=librosa.display.specshow(y, sr=Fs, x_axis='time', y_axis='log')
    plt.ylim(10, 8500)
    fig.colorbar(img, ax=ax, format="%+2.f dB")
    mPlotArray.setValueFig(fig)    

def setMelSpecGram():
    global Fs,N,CH,data
    # 提取梅尔频谱
    melspec = librosa.feature.melspectrogram(y=data,sr=Fs)
    # 将梅尔频率数据做对数变换
    logmelspec = librosa.power_to_db(melspec,ref=np.max)
    plt.close('all')
    fig, ax = plt.subplots(1,1)
    img=librosa.display.specshow(logmelspec, sr=Fs, x_axis='time', y_axis='mel')
    plt.ylim(10, 8500)
    fig.colorbar(img, ax=ax, format="%+2.f dB")
    mPlotArray.setValueFig(fig)  
            
def setPlay(v):
    global Fs,N,CH,data,mPosition,mLength,pObj;
    if N==0: return;
    if v==0: pObj=sa.play(1,Fs,data,0)
    if v==1: pObj.stop()

def setTime(v):
    global Fs,N,CH,data,xdata,mPosition,mLength,pObj;
    if Fs==0:
        mTimer2.setValueSingle(1)
        return;
    T=N/Fs
    v=v/1000
    if v>T:
        pObj.stop()
        mTimer2.setValueSingle(1)
    else:
        n1=int(v*Fs)
        n2=int(0.15*Fs)
        xx=data[n1:n1+n2]
        mPlotWave1.setValue2DX(1/Fs,xx)  

def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)
    
#==Main Window=====================
win= tk.Tk()
winWidthCur=1100
winHeightCur=700
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-音乐文件信号波形浏览')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','音乐文件语谱图分析',20)
mBut1=dr.DRButton(win,630,25,100,36,'#003355','#eeee00','打开文件',12,101)
mOMenu=dr.DROptionMenu(win,740,25,100,36,'#003355','#eeee00','样例1,样例2,样例3',12,0)
mPlotWave=dr.DRPlot(win,20,75,660,150,'','#113344','#000000','#ffffff','#00eeff','#00ff00',0,0,-1,1,0,0)
mPlotWave1=dr.DRPlot(win,680,75,400,150,'','#113344','#000000','#ffffff','#00eeff','#00ff00',0,0,-1,1,0,0)
mHBut5=dr.DRHButtonGroup(win,850,25,160,36,'#003355','#ffffff','播放,停止',12,0)
mHBut5.addCallBackSingle(setPlay) 
mTimer2=dr.DRTimer(win,1020,25,60,36,'#000000','#ffff00',150,11)
mTimer2.addCallBackSingle(setTime)
mHBut5.addCallBackSingle(mTimer2.setValueSingle)
mBut1.addCallBackSingle(setValueSingle)
mPlotArray=dr.DRFigure(win,20,235,1060,450,cb='#003355',cb1='#000000',cf='#ffffff',cf1='#009999',cf2='#ffff00')
mOpt=dr.DROptionMenu(win,470,25,120,36,txt='线性,对数,梅尔',val=2)
mOpt.addCallBackSingle(doSpec)
mOMenu.addCallBackSingle(setDemo)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mPlotWave)
mWidSize.addDRWidget(mHBut5) 
mWidSize.addDRWidget(mTimer2)
mWidSize.addDRWidget(mOMenu)
mWidSize.addDRWidget(mPlotWave1)
mWidSize.addDRWidget(mPlotWave)
mWidSize.addDRWidget(mPlotArray) 
mWidSize.addDRWidget(mOpt)
#==========================================
mPosition=0
mLength=8192
setDemo(0)
#==Main Loop=====================
win.mainloop()

#==End of APPp=====================

