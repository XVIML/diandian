#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
import tkinter as tk
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.datasets import load_wine
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import drvi.drviControlls as dr
        
#==Event response function of controls====
def setSignal(v):   
    global N,Fs,t,x
    if v==0:
        abc = load_iris()
        M=4
    if v==1:
        abc = load_wine()
        M=13        
    X = abc.data
    Y=abc.target
    mPlot.clearFig(wn=M)
    for i in range(M):
        mPlot.setValue2DXM(i,1,X[:,i],cl=1)
    #PCA==================
    X=StandardScaler().fit(X).transform(X)
    pca = PCA(n_components=2)
    H=pca.fit_transform(X)
    #Draw Result=========
    mPlot1.clearFig(wn=2)
    mPlot1.setValue2DXM(0,1,H[:,0],cl=1)
    mPlot1.setValue2DXM(1,1,H[:,1],cl=1)
    fig, ax = plt.subplots(1,1)
    fig.tight_layout()
    plt.scatter(H[:,0],H[:,1],c=Y)
    mPlot2.setValueFig(fig)  
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-数据的PCA降维和可视化')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,500,40,'#440000','#ffffff','数据的PCA降维和可视化',20)
mHBut=dr.DRHButtonGroup(win,740,25,300,36,'#003355','#ffffff','鸢尾花卉数据集,红酒数据集',12,0)
mTab=dr.DRNoteBook(win,20,75,1020,590,txt='原始数据,降维数据,降维度散点图')
mPlot=dr.DRMonitor(mTab.win[0],10,10,998,540)
mPlot1=dr.DRMonitor(mTab.win[1],10,10,998,540,wn=2)
mPlot2=dr.DRFigure(mTab.win[2],10,10,998,540,cb='#cccccc',cb1='#aaaaaa',cf='#000000',cf1='#000000',cf2='#ffff00')
#===============================
mHBut.addCallBackSingle(setSignal)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mHBut)
mWidSize.addDRWidget(mTab)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mPlot1)
mWidSize.addDRWidget(mPlot2)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

