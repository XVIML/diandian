#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
import tkinter as tk
from scipy import signal
import drvi.drviDSP as dsp
import drvi.drviControlls as dr


#==FastICA===================
# Definition of G'
def Gprime(x):
    return np.tanh(x)

# Definition of G''
def Gsecond(x):
    return np.ones(x.shape)-np.power(np.tanh(x),2)

# Center matrix X
def centerMatrix(X, N):
    mean = X.mean(axis=1)
    M = X - (mean.reshape((N, 1)) @ np.ones((1, X.shape[1])))
    return M

# Whiten matrix X with eigenvalue decomposition
def whitenMatrix(X):
    D, E = np.linalg.eigh(X @ X.T)
    DE = np.diag(1/np.sqrt(D + 1e-5)) @ E.T    
    return DE @ X

# One-unit algorithm step
def oneUnit(X, wp):
    term1 = np.mean((X @ Gprime(wp @ X).T), axis=1)
    term2 = np.mean(Gsecond(wp @ X), axis=1) * wp
    return term1 - term2

# Deflationary orthogonalization
def orthogonalize(W, wp, i):
    return wp - ((wp @ W[:i,:].T) @ W[:i,:])

# wp normalization
def normalize(wp):
    return wp / np.linalg.norm(wp)

def fastICA(X, C, max_iter):
    N = X.shape[0]
    X = centerMatrix(X, N)
    X = whitenMatrix(X)    
    W = np.zeros((C, N))
    for i in range(C):
        wp = np.random.rand(1, N)
        for _ in range(max_iter):
            wp = oneUnit(X, wp)
            wp = orthogonalize(W, wp, i)
            wp = normalize(wp)
            W[i,:] = wp
    return W @ X
#==========================================
  
        
#==Event response function of controls====
def setSignal(v):   
    global N,Fs,t,s1,s2,x1,x2
    N=2000
    t=np.linspace(0,8,N)
    s1=np.sin(5*t)
    s2=signal.sawtooth(2*np.pi*t)
    x1=0.3*s1+0.5*s2
    x2=0.8*s1-0.5*s2
    resetWave(0)

def resetWave(v):
    global N,Fs,t,s1,s2,x1,x2
    mPlot.setValue2DM(0,t,s1,'#ffff00',ylow=-1.5,yhigh=1.5)
    mPlot.setValue2DM(1,t,s2,'#00ffff',ylow=-1.5,yhigh=1.5)    
    mPlot.setValue2DM(2,t,x1,'#ffff00',ylow=-1.5,yhigh=1.5)
    mPlot.setValue2DM(3,t,x2,'#00ffff',ylow=-1.5,yhigh=1.5)
    mPlot.setValue2DM(4,t,x1*0,'#ffff00',ylow=-1.5,yhigh=1.5)
    mPlot.setValue2DM(5,t,x2*0,'#00ffff',ylow=-1.5,yhigh=1.5)

def doCalc(v):
    global N,Fs,t,x1,x2
    X=np.c_[x1[0:N],x2[0:N]]
    X=np.rot90(X,-1)
    S = fastICA(X,2,32)
    y1=S[0,:]/np.max(S[0,:])
    y2=S[1,:]/np.max(S[1,:])
    mPlot.setValue2DM(4,t,y1,'#ffff00',ylow=-1.5,yhigh=1.5)
    mPlot.setValue2DM(5,t,y2,'#00ffff',ylow=-1.5,yhigh=1.5)
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-读懂FsatICA盲源分离算法')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','读懂FastICA盲源分离算法',20)
mBut1=dr.DRButton(win,910,25,60,36,txt='计算')
mBut2=dr.DRButton(win,980,25,60,36,txt='重置')
mPlot=dr.DRMonitor(win,20,70,1020,580,wn=6)
#===============================
mBut1.addCallBackSingle(doCalc)
mBut2.addCallBackSingle(resetWave)
setSignal(0)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mBut2)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

