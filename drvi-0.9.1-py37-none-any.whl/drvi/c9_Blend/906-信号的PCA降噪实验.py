#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
import tkinter as tk
import matplotlib.pyplot as plt
from scipy.linalg import svd
from scipy.linalg import hankel
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
#from scipy.misc import electrocardiogram
from drvi.misc import electrocardiogram
from scipy.io import loadmat
import drvi.drviControlls as dr
        
#==Event response function of controls====
def setSignal(v):
    M=128
    N=2500
    mPlot.clearFig(wn=2)
    if v==0:        
        ecg=electrocardiogram()
        x=ecg[256:256+N]
        mPlot.setValue2DXM(0,1,x,cl=1)
    if v==1:
        mFile=mPath.getDRVIPath()+'\\dataset\\leleccum.mat'
        mat = loadmat(mFile)
        x = mat['leleccum'][0][0:N]
        mPlot.setValue2DXM(0,1,x,cl=1)
    #PCA Denoise====
    L=N-M
    A=np.zeros((M,L))
    for i in range(M): A[i]=x[i:i+L]
    U,S,Vt=svd(A)
    #==前k个奇异值信号重构
    k=8
    EL=np.zeros((U.shape[1],Vt.shape[0]))
    EL[:k, :k]=np.diag(S[:k])
    AA = U @ EL @ Vt
    mPlot.setValue2DXM(1,1,AA[0,:],cl=1)
       
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-信号的PCA降噪实验')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,500,40,'#440000','#ffffff','信号的PCA降噪实验',20)
mHBut=dr.DRHButtonGroup(win,740,25,300,36,'#003355','#ffffff','ECG信号,电网电压信号',12,0)
mPlot=dr.DRMonitor(win,20,70,1029,580,wn=2)
#===============================
mHBut.addCallBackSingle(setSignal)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mHBut)
mWidSize.addDRWidget(mPlot)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

