#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
import tkinter as tk
import matplotlib.pyplot as plt
from scipy.linalg import svd
#from scipy.misc import electrocardiogram
from drvi.misc import electrocardiogram
from scipy.io import loadmat
import drvi.drviControlls as dr

def normSig(x):
    x=x-np.mean(x)
    x=x/np.max(x)
    return x

def setSignal(v):
    global L,x,Y;
    M=128; N=2500; L=N-M
    Y=np.zeros((10,L))
    if v==0:        
        ecg=electrocardiogram()
        x=ecg[256:256+N]
    if v==1:
        mFile=mPath.getDRVIPath()+'\\dataset\\leleccum.mat'
        mat = loadmat(mFile)
        x = mat['leleccum'][0][0:N]
    x=normSig(x)
    mPlot.clearFig(wn=11)
    mPlot.setValue2DXM(0,1,x[0:L],ylow=-1,yhigh=1,cl=1)
    #PCA Denoise====
    A=np.zeros((M,L))
    for i in range(M): A[i]=x[i:i+L]
    U,S,Vt=svd(A)
    #==前10个奇异值分别对应的信号
    D=np.diag(S)
    for k in range(10):
        EL=np.zeros((U.shape[1],Vt.shape[0]))
        EL[k,k]=D[k,k]
        AA = U @ EL @ Vt
        Y[k]=AA[0,:]        
        mPlot.setValue2DXM(k+1,1,Y[k],ylow=-1,yhigh=1,cl=1)

def setADD(v):
    global L,x,Y;
    txt=mEntry.getValueString()
    ll=txt.split(',')    
    NN=len(ll)
    print(NN)
    z=np.zeros(L)
    for i in range(NN):
        k=int(ll[i])
        z=z+Y[k-1]
    fig, axs = plt.subplots(2, 1)
    axs[0].plot(x[0:L])
    axs[0].set_ylim(-1,1)
    axs[1].plot(z)
    axs[1].set_ylim(-1,1)
    plt.show()

       
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-信号的PCA多尺度分解与合成实验')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','信号PCA多尺度分解与合成',20)
mHBut=dr.DRHButtonGroup(win,440,25,260,36,'#003355','#ffffff','ECG信号,电网电压信号',12,0)
mPlot=dr.DRMonitor(win,20,70,1029,580,wn=11)
mBut=dr.DRButton(win,740,25,80,36,'#00aacc','#eeee00','合成',12,101)
mEntry=dr.DREntry(win,825,25,220,36,'#ffffff','#000000','1,2,3,4,5,6,7,8,9,10',16)
#===============================
mHBut.addCallBackSingle(setSignal)
mBut.addCallBackSingle(setADD)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mHBut)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mBut)
mWidSize.addDRWidget(mEntry)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

