#Add current Python working path, remove it, if you original python is ok.
import drvi.drviAppendPath as mPath
mPath.appendPythonPath()
#====================================================================
import numpy as np
from scipy import signal
import tkinter as tk
from tkinter import filedialog
import librosa
from sklearn.decomposition import FastICA
import drvi.drviControlls as dr
import drvi.drviSimpleAudio as sa

#=================================================
def getSim(v):
    global Fs,s1,s2,s3;
    Fs=44100; N=Fs*10; dt=1/Fs
    t=np.arange(N)*dt
    s1=0.5*np.sin(2*np.pi*10*t)*(1.2+np.sin(2*np.pi*1*t))
    s2=np.sin(2*np.pi*(1+1*t)*t)
    s3=np.sign(np.sin(2*np.pi*1*t))    
    cutWAV()
    getMix(0)
    solveMix()

    
def getFile(v):
    global Fs,s1,s2,s3;
    if v==3:
        mName1=mPath.getDRVIPath()+'\\dataset\\voice1.mp3'
        mName2=mPath.getDRVIPath()+'\\dataset\\voice2.mp3'
        mName3=mPath.getDRVIPath()+'\\dataset\\voice3.mp3'
        getWAV(0,mName1);
        getWAV(1,mName2)
        getWAV(2,mName3)        
    else:
        mfile=filedialog.askopenfilename(title="选择文件",filetypes=(("MP3 files", "*.mp3"),("WAV files", "*.wav"),("all files", "*.*")))
        if not mfile: return 1
        else: getWAV(v,mfile)
    cutWAV()
    getMix(0)
    solveMix()

def getWAV(v,name):
    global Fs,s1,s2,s3;
    y,Fs=librosa.load(name,mono=True)
    if v==0: s1=y
    if v==1: s2=y
    if v==2: s3=y
        
def cutWAV():
    global Fs,s1,s2,s3,S;
    N=np.min([len(s1),len(s2),len(s3)])
    S=np.c_[s1[0:N],s2[0:N],s3[0:N]]
    mPlot.setValue2DXM(0,1/Fs,S[:,0],'#ffff00',ylow=-1.25,yhigh=1.25)
    mPlot.setValue2DXM(1,1/Fs,S[:,1],'#00ffff',ylow=-1.25,yhigh=1.25)
    mPlot.setValue2DXM(2,1/Fs,S[:,2],'#00ff00',ylow=-1.25,yhigh=1.25) 
    
def doPlay(v):
    global Fs,s1,s2,s3,S,X,SE;
    if v==0: y=S[:,0]/np.max(S[:,0])
    if v==1: y=S[:,1]/np.max(S[:,1])
    if v==2: y=S[:,2]/np.max(S[:,2])
    if v==3: y=X[:,0]/np.max(X[:,0])
    if v==4: y=X[:,1]/np.max(X[:,1])
    if v==5: y=X[:,2]/np.max(X[:,2])
    if v==6: y=SE[:,0]/np.max(SE[:,0])
    if v==7: y=SE[:,1]/np.max(SE[:,1])
    if v==8: y=SE[:,2]/np.max(SE[:,2])    
    sa.play(1,Fs,y,0)
 
def getMix(v):
    global Fs,A,S,X
    A=np.array([[1,1,1],[1,1,1],[1,1,1]])
    txt1=mEntry1.getValueString()
    txt2=mEntry2.getValueString()
    txt3=mEntry3.getValueString()
    LL1=txt1.split(',');  LL2=txt2.split(',');  LL3=txt3.split(',')
    A[0,0]=float(LL1[0]); A[0,1]=float(LL1[1]); A[0,2]=float(LL1[2])
    A[1,0]=float(LL2[0]); A[1,1]=float(LL2[1]); A[1,2]=float(LL2[2])
    A[2,0]=float(LL3[0]); A[2,1]=float(LL3[1]); A[2,2]=float(LL3[2])
    X=np.dot(S,A.T)
    X[:,0]=X[:,0]/np.max(X[:,0])
    X[:,1]=X[:,1]/np.max(X[:,1])
    X[:,2]=X[:,2]/np.max(X[:,2])
    mPlot1.setValue2DXM(0,1/Fs,X[:,0],'#ffff00',ylow=-1.25,yhigh=1.25)
    mPlot1.setValue2DXM(1,1/Fs,X[:,1],'#00ffff',ylow=-1.25,yhigh=1.25)
    mPlot1.setValue2DXM(2,1/Fs,X[:,2],'#00ff00',ylow=-1.25,yhigh=1.25)
    print(1)

def solveMix():
    global Fs,A,S,X,SE
    ica = FastICA(n_components=3)
    SE=ica.fit_transform(X)
    SE[:,0]=SE[:,0]/np.max(SE[:,0])
    SE[:,1]=SE[:,1]/np.max(SE[:,1])
    SE[:,2]=SE[:,2]/np.max(SE[:,2])    
    mPlot2.setValue2DXM(0,1/Fs,SE[:,0],'#ffff00',ylow=-1.25,yhigh=1.25)
    mPlot2.setValue2DXM(1,1/Fs,SE[:,1],'#00ffff',ylow=-1.25,yhigh=1.25)
    mPlot2.setValue2DXM(2,1/Fs,SE[:,2],'#00ff00',ylow=-1.25,yhigh=1.25)       
    
        
#==Event response function of controls====
def setSignal(v):   
    global N,Fs,t,s1,s2,x1,x2
    N=2000
    t=np.linspace(0,8,N)
    s1=np.sin(5*t)
    s2=signal.sawtooth(2*np.pi*t)
    x1=0.3*s1+0.5*s2
    x2=0.8*s1-0.5*s2
    
#====================================
def winResize(event):
    w=win.winfo_width()
    h=win.winfo_height()
    mWidSize.resize(w,h)

#==Main Window=====================
win= tk.Tk()
winWidthCur=1060
winHeightCur=680
win.geometry("%dx%d" %(winWidthCur,winHeightCur))
win.config(bg="#ddeeee")
win.bind('<Configure>',winResize) 
mWidSize=dr.DRResize(winWidthCur,winHeightCur)
win.wm_title('DRVI-音频信号的盲源分离')
#==Layout of controls=====================
mL1=dr.DRLabel(win,20,20,400,40,'#440000','#ffffff','音频信号的盲源分离',20) 
mBut=dr.DRHButtonGroup(win,440,25,330,36,txt='音频1,音频2,音频3,默认音频')
mButSim=dr.DRButton(win,790,25,100,36,txt='仿真信号')
mButMenu=dr.DROptionMenu(win,900,25,140,36,txt='播放源音1,播放源音2,播放源音3,播放混音1,播放混音2,播放混音3,播放分离音1,播放分离音2,播放分离音3')
mTab=dr.DRNoteBook(win,20,75,1020,590,txt='源音频信号,混合的音频信号,盲源分离的音频信号')
mPlot=dr.DRMonitor(mTab.win[0],10,10,998,540,wn=3)
mPlot1=dr.DRMonitor(mTab.win[1],10,10,998,500,wn=3)
mBut1=dr.DRButton(mTab.win[1],10,520,120,36,txt='重新混音')
mEntry1=dr.DREntry(mTab.win[1],140,520,140,36,txt='1.0,1.0,1.0')
mEntry2=dr.DREntry(mTab.win[1],290,520,140,36,txt='0.5,2.0,1.0')
mEntry3=dr.DREntry(mTab.win[1],450,520,140,36,txt='1.5,1.0,0.5')
mPlot2=dr.DRMonitor(mTab.win[2],10,10,998,540,wn=3)
#===============================
mButMenu.addCallBackSingle(doPlay)
mBut.addCallBackSingle(getFile)
mBut1.addCallBackSingle(getMix)
mButSim.addCallBackSingle(getSim)
getSim(0)
#===============================
mWidSize.addDRWidget(mL1)
mWidSize.addDRWidget(mPlot)
mWidSize.addDRWidget(mTab)
mWidSize.addDRWidget(mBut)
mWidSize.addDRWidget(mButSim)
mWidSize.addDRWidget(mButMenu)
mWidSize.addDRWidget(mPlot1)
mWidSize.addDRWidget(mBut1)
mWidSize.addDRWidget(mEntry1)
mWidSize.addDRWidget(mEntry2)
mWidSize.addDRWidget(mEntry3)
mWidSize.addDRWidget(mPlot2)
#==Main Loop=====================
win.mainloop()
#==End of APPp=====================

